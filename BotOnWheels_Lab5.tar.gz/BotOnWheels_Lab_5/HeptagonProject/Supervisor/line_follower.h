/* --- Generated the 9/4/2025 at 2:51 --- */
/* --- heptagon compiler, version 1.05.00 (compiled wed. mar. 19 17:12:18 CET 2025) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts line_follower.ept --- */

#ifndef LINE_FOLLOWER_H
#define LINE_FOLLOWER_H

#include "line_follower_types.h"
typedef struct Line_follower__abs_out {
  long b;
} Line_follower__abs_out;

void Line_follower__abs_step(long a, Line_follower__abs_out* _out);

typedef struct Line_follower__line_follower_mem {
  Line_follower__st ck;
  long v_114;
  long v_112;
  long v_145;
  long v_143;
  long v_156;
  long v_154;
  long v_187;
  long v_185;
  long v_218;
  long v_216;
  long v_229;
  long v_227;
  long v_260;
  long v_258;
  long v_271;
  long v_269;
  long v_15;
  long v_14;
  long pnr;
  long error_1;
} Line_follower__line_follower_mem;

typedef struct Line_follower__line_follower_out {
  long v_l;
  long v_r;
  long dir;
  long correction;
  long stateno;
} Line_follower__line_follower_out;

void Line_follower__line_follower_reset(Line_follower__line_follower_mem* self);

void Line_follower__line_follower_step(long sen[5], long ir0, long ir1, long ir2,
                                       long ir3, long ir4, long line_switch,
                                       Line_follower__line_follower_out* _out,
                                       Line_follower__line_follower_mem* self);

typedef struct Line_follower__main_mem {
  long v_294;
  long v_293;
  Line_follower__line_follower_mem line_follower;
} Line_follower__main_mem;

typedef struct Line_follower__main_out {
  long v_l;
  long v_r;
  long dir;
  long correction;
  long stateno;
  long err;
  long line_switch;
} Line_follower__main_out;

void Line_follower__main_reset(Line_follower__main_mem* self);

void Line_follower__main_step(long sen0, long sen1, long sen2, long sen3,
                              long sen4, long ir0, long ir1, long ir2, long ir3,
                              long ir4, Line_follower__main_out* _out,
                              Line_follower__main_mem* self);

#endif // LINE_FOLLOWER_H
