/* --- Generated the 9/4/2025 at 2:51 --- */
/* --- heptagon compiler, version 1.05.00 (compiled wed. mar. 19 17:12:18 CET 2025) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts line_follower.ept --- */

#ifndef LINE_FOLLOWER_TYPES_H
#define LINE_FOLLOWER_TYPES_H

#include "stdbool.h"
#include "assert.h"
#include "pervasives.h"
typedef enum {
  Line_follower__St_Zstartstate,
  Line_follower__St_Whitepath,
  Line_follower__St_Stop,
  Line_follower__St_Revertfromobstacle,
  Line_follower__St_ParkingPath,
  Line_follower__St_ParkingOccupied,
  Line_follower__St_Obstacleedge3,
  Line_follower__St_Obstacleedge2_straight,
  Line_follower__St_Obstacleedge2,
  Line_follower__St_Obstacleedge1_straight,
  Line_follower__St_Obstacleedge1,
  Line_follower__St_Obstacle3_turn1,
  Line_follower__St_Obstacle3_straight,
  Line_follower__St_FreePlace,
  Line_follower__St_Blackpath_afterobstacle,
  Line_follower__St_Blackpath3,
  Line_follower__St_Blackpath2,
  Line_follower__St_Blackpath1,
  Line_follower__St_Blackjunction4,
  Line_follower__St_Blackjunction3,
  Line_follower__St_Blackjunction2,
  Line_follower__St_Blackjunction1
} Line_follower__st;

Line_follower__st Line_follower__st_of_string(char* s);

char* string_of_Line_follower__st(Line_follower__st x, char* buf);

#endif // LINE_FOLLOWER_TYPES_H
