/* --- Generated the 9/4/2025 at 2:51 --- */
/* --- heptagon compiler, version 1.05.00 (compiled wed. mar. 19 17:12:18 CET 2025) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts line_follower.ept --- */

#ifndef LINE_FOLLOWER_H
#define LINE_FOLLOWER_H

#include "line_follower_types.h"
typedef struct Line_follower__abs_out {
  int b;
} Line_follower__abs_out;

void Line_follower__abs_step(int a, Line_follower__abs_out* _out);

typedef struct Line_follower__line_follower_mem {
  Line_follower__st ck;
  int v_114;
  int v_112;
  int v_145;
  int v_143;
  int v_156;
  int v_154;
  int v_187;
  int v_185;
  int v_218;
  int v_216;
  int v_229;
  int v_227;
  int v_260;
  int v_258;
  int v_271;
  int v_269;
  int v_15;
  int v_14;
  int pnr;
  int error_1;
} Line_follower__line_follower_mem;

typedef struct Line_follower__line_follower_out {
  int v_l;
  int v_r;
  int dir;
  int correction;
  int stateno;
} Line_follower__line_follower_out;

void Line_follower__line_follower_reset(Line_follower__line_follower_mem* self);

void Line_follower__line_follower_step(int sen[5], int ir0, int ir1, int ir2,
                                       int ir3, int ir4, int line_switch,
                                       Line_follower__line_follower_out* _out,
                                       Line_follower__line_follower_mem* self);

typedef struct Line_follower__main_mem {
  int v_294;
  int v_293;
  Line_follower__line_follower_mem line_follower;
} Line_follower__main_mem;

typedef struct Line_follower__main_out {
  int v_l;
  int v_r;
  int dir;
  int correction;
  int stateno;
  int err;
  int line_switch;
} Line_follower__main_out;

void Line_follower__main_reset(Line_follower__main_mem* self);

void Line_follower__main_step(int sen0, int sen1, int sen2, int sen3,
                              int sen4, int ir0, int ir1, int ir2, int ir3,
                              int ir4, Line_follower__main_out* _out,
                              Line_follower__main_mem* self);

#endif // LINE_FOLLOWER_H
