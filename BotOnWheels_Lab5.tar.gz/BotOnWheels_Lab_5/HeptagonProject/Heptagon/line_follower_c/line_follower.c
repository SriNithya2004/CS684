/* --- Generated the 9/4/2025 at 2:51 --- */
/* --- heptagon compiler, version 1.05.00 (compiled wed. mar. 19 17:12:18 CET 2025) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts line_follower.ept --- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "line_follower.h"

void Line_follower__abs_step(int a, Line_follower__abs_out* _out) {
  
  int v_1;
  int v;
  v_1 = -(a);
  v = (a<0);
  if (v) {
    _out->b = v_1;
  } else {
    _out->b = a;
  };;
}

void Line_follower__line_follower_reset(Line_follower__line_follower_mem* self) {
  self->v_269 = true;
  self->v_258 = true;
  self->v_227 = true;
  self->v_216 = true;
  self->v_185 = true;
  self->v_154 = true;
  self->v_143 = true;
  self->v_112 = true;
  self->error_1 = 0;
  self->pnr = false;
  self->ck = Line_follower__St_Zstartstate;
  self->v_14 = true;
}

void Line_follower__line_follower_step(int sen[5], int ir0, int ir1, int ir2,
                                       int ir3, int ir4, int line_switch,
                                       Line_follower__line_follower_out* _out,
                                       Line_follower__line_follower_mem* self) {
  Line_follower__abs_out Line_follower__abs_out_st;
  
  int v_25;
  int v_24;
  int v_34;
  int v_33;
  int v_32;
  int v_31;
  int v_30;
  int v_29;
  int v_28;
  int v_27;
  int v_26;
  int v_45;
  int v_44;
  int v_43;
  int v_42;
  int v_41;
  int v_40;
  int v_39;
  int v_38;
  int v_37;
  int v_36;
  int v_35;
  int r_St_Stop;
  Line_follower__st s_St_Stop;
  int r_St_FreePlace;
  Line_follower__st s_St_FreePlace;
  int r_St_ParkingOccupied;
  Line_follower__st s_St_ParkingOccupied;
  int r_St_ParkingPath;
  Line_follower__st s_St_ParkingPath;
  int r_St_Blackjunction4;
  Line_follower__st s_St_Blackjunction4;
  int r_St_Blackpath3;
  Line_follower__st s_St_Blackpath3;
  int r_St_Blackjunction3;
  Line_follower__st s_St_Blackjunction3;
  int r_St_Blackpath_afterobstacle;
  Line_follower__st s_St_Blackpath_afterobstacle;
  int r_St_Revertfromobstacle;
  Line_follower__st s_St_Revertfromobstacle;
  int r_St_Obstacle3_straight;
  Line_follower__st s_St_Obstacle3_straight;
  int r_St_Obstacle3_turn1;
  Line_follower__st s_St_Obstacle3_turn1;
  int r_St_Obstacleedge3;
  Line_follower__st s_St_Obstacleedge3;
  int r_St_Obstacleedge2_straight;
  Line_follower__st s_St_Obstacleedge2_straight;
  int r_St_Obstacleedge2;
  Line_follower__st s_St_Obstacleedge2;
  int r_St_Obstacleedge1_straight;
  Line_follower__st s_St_Obstacleedge1_straight;
  int r_St_Obstacleedge1;
  Line_follower__st s_St_Obstacleedge1;
  int r_St_Blackpath2;
  Line_follower__st s_St_Blackpath2;
  int r_St_Blackjunction2;
  Line_follower__st s_St_Blackjunction2;
  int r_St_Blackpath1;
  Line_follower__st s_St_Blackpath1;
  int r_St_Blackjunction1;
  Line_follower__st s_St_Blackjunction1;
  int r_St_Whitepath;
  Line_follower__st s_St_Whitepath;
  int r_St_Zstartstate;
  Line_follower__st s_St_Zstartstate;
  int v_60;
  int v_59;
  int v_58;
  int v_57;
  int v_56;
  int v_55;
  int v_54;
  int v_53;
  int v_52;
  int v_51;
  int v_50;
  int v_49;
  int v_48;
  int v_47;
  int v_46;
  int v_86;
  int v_85;
  int v_84;
  int v_83;
  int v_82;
  int v_81;
  int v_80;
  int v_79;
  int v_78;
  int v_77;
  int v_76;
  int v_75;
  int v_74;
  int v_73;
  int v_72;
  int v_71;
  int v_70;
  int v_69;
  int v_68;
  int v_67;
  int v_66;
  int v_65;
  int v_64;
  int v_63;
  int v_62;
  int v_61;
  int v_104;
  int v_103;
  int v_102;
  int v_101;
  int v_100;
  int v_99;
  int v_98;
  int v_97;
  int v_96;
  int v_95;
  int v_94;
  int v_93;
  int v_92;
  int v_91;
  int v_90;
  int v_89;
  int v_88;
  int v_87;
  int v_115;
  int v_113;
  int v_111;
  int v_110;
  int v_109;
  int v_108;
  int v_107;
  int v_106;
  int v_105;
  int v_146;
  int v_144;
  int v_142;
  int v_141;
  int v_140;
  int v_139;
  int v_138;
  int v_137;
  int v_136;
  int v_135;
  int v_134;
  int v_133;
  int v_132;
  int v_131;
  int v_130;
  int v_129;
  int v_128;
  int v_127;
  int v_126;
  int v_125;
  int v_124;
  int v_123;
  int v_122;
  int v_121;
  int v_120;
  int v_119;
  int v_118;
  int v_117;
  int v_116;
  int v_157;
  int v_155;
  int v_153;
  int v_152;
  int v_151;
  int v_150;
  int v_149;
  int v_148;
  int v_147;
  int v_188;
  int v_186;
  int v_184;
  int v_183;
  int v_182;
  int v_181;
  int v_180;
  int v_179;
  int v_178;
  int v_177;
  int v_176;
  int v_175;
  int v_174;
  int v_173;
  int v_172;
  int v_171;
  int v_170;
  int v_169;
  int v_168;
  int v_167;
  int v_166;
  int v_165;
  int v_164;
  int v_163;
  int v_162;
  int v_161;
  int v_160;
  int v_159;
  int v_158;
  int v_190;
  int v_189;
  int v_191;
  int v_193;
  int v_192;
  int v_194;
  int v_196;
  int v_195;
  int v_219;
  int v_217;
  int v_215;
  int v_214;
  int v_213;
  int v_212;
  int v_211;
  int v_210;
  int v_209;
  int v_208;
  int v_207;
  int v_206;
  int v_205;
  int v_204;
  int v_203;
  int v_202;
  int v_201;
  int v_200;
  int v_199;
  int v_198;
  int v_197;
  int v_230;
  int v_228;
  int v_226;
  int v_225;
  int v_224;
  int v_223;
  int v_222;
  int v_221;
  int v_220;
  int v_261;
  int v_259;
  int v_257;
  int v_256;
  int v_255;
  int v_254;
  int v_253;
  int v_252;
  int v_251;
  int v_250;
  int v_249;
  int v_248;
  int v_247;
  int v_246;
  int v_245;
  int v_244;
  int v_243;
  int v_242;
  int v_241;
  int v_240;
  int v_239;
  int v_238;
  int v_237;
  int v_236;
  int v_235;
  int v_234;
  int v_233;
  int v_232;
  int v_231;
  int v_272;
  int v_270;
  int v_268;
  int v_267;
  int v_266;
  int v_265;
  int v_264;
  int v_263;
  int v_262;
  int v_289;
  int v_288;
  int v_287;
  int v_286;
  int v_285;
  int v_284;
  int v_283;
  int v_282;
  int v_281;
  int v_280;
  int v_279;
  int v_278;
  int v_277;
  int v_276;
  int v_275;
  int v_274;
  int v_273;
  int nr_St_Stop;
  Line_follower__st ns_St_Stop;
  int time_St_Stop;
  int stateno_St_Stop;
  int dir_St_Stop;
  int v_r_St_Stop;
  int v_l_St_Stop;
  int nr_St_FreePlace;
  Line_follower__st ns_St_FreePlace;
  int time_St_FreePlace;
  int stateno_St_FreePlace;
  int dir_St_FreePlace;
  int v_r_St_FreePlace;
  int v_l_St_FreePlace;
  int nr_St_ParkingOccupied;
  Line_follower__st ns_St_ParkingOccupied;
  int time_St_ParkingOccupied;
  int stateno_St_ParkingOccupied;
  int dir_St_ParkingOccupied;
  int v_r_St_ParkingOccupied;
  int v_l_St_ParkingOccupied;
  int nr_St_ParkingPath;
  Line_follower__st ns_St_ParkingPath;
  int time_St_ParkingPath;
  int stateno_St_ParkingPath;
  int dir_St_ParkingPath;
  int v_r_St_ParkingPath;
  int v_l_St_ParkingPath;
  int nr_St_Blackjunction4;
  Line_follower__st ns_St_Blackjunction4;
  int time_St_Blackjunction4;
  int stateno_St_Blackjunction4;
  int dir_St_Blackjunction4;
  int v_r_St_Blackjunction4;
  int v_l_St_Blackjunction4;
  int nr_St_Blackpath3;
  Line_follower__st ns_St_Blackpath3;
  int time_St_Blackpath3;
  int stateno_St_Blackpath3;
  int dir_St_Blackpath3;
  int v_r_St_Blackpath3;
  int v_l_St_Blackpath3;
  int nr_St_Blackjunction3;
  Line_follower__st ns_St_Blackjunction3;
  int time_St_Blackjunction3;
  int stateno_St_Blackjunction3;
  int dir_St_Blackjunction3;
  int v_r_St_Blackjunction3;
  int v_l_St_Blackjunction3;
  int nr_St_Blackpath_afterobstacle;
  Line_follower__st ns_St_Blackpath_afterobstacle;
  int time_St_Blackpath_afterobstacle;
  int stateno_St_Blackpath_afterobstacle;
  int dir_St_Blackpath_afterobstacle;
  int v_r_St_Blackpath_afterobstacle;
  int v_l_St_Blackpath_afterobstacle;
  int nr_St_Revertfromobstacle;
  Line_follower__st ns_St_Revertfromobstacle;
  int time_St_Revertfromobstacle;
  int stateno_St_Revertfromobstacle;
  int dir_St_Revertfromobstacle;
  int v_r_St_Revertfromobstacle;
  int v_l_St_Revertfromobstacle;
  int nr_St_Obstacle3_straight;
  Line_follower__st ns_St_Obstacle3_straight;
  int time_St_Obstacle3_straight;
  int stateno_St_Obstacle3_straight;
  int dir_St_Obstacle3_straight;
  int v_r_St_Obstacle3_straight;
  int v_l_St_Obstacle3_straight;
  int nr_St_Obstacle3_turn1;
  Line_follower__st ns_St_Obstacle3_turn1;
  int time_St_Obstacle3_turn1;
  int stateno_St_Obstacle3_turn1;
  int dir_St_Obstacle3_turn1;
  int v_r_St_Obstacle3_turn1;
  int v_l_St_Obstacle3_turn1;
  int nr_St_Obstacleedge3;
  Line_follower__st ns_St_Obstacleedge3;
  int time_St_Obstacleedge3;
  int stateno_St_Obstacleedge3;
  int dir_St_Obstacleedge3;
  int v_r_St_Obstacleedge3;
  int v_l_St_Obstacleedge3;
  int nr_St_Obstacleedge2_straight;
  Line_follower__st ns_St_Obstacleedge2_straight;
  int time_St_Obstacleedge2_straight;
  int stateno_St_Obstacleedge2_straight;
  int dir_St_Obstacleedge2_straight;
  int v_r_St_Obstacleedge2_straight;
  int v_l_St_Obstacleedge2_straight;
  int nr_St_Obstacleedge2;
  Line_follower__st ns_St_Obstacleedge2;
  int time_St_Obstacleedge2;
  int stateno_St_Obstacleedge2;
  int dir_St_Obstacleedge2;
  int v_r_St_Obstacleedge2;
  int v_l_St_Obstacleedge2;
  int nr_St_Obstacleedge1_straight;
  Line_follower__st ns_St_Obstacleedge1_straight;
  int time_St_Obstacleedge1_straight;
  int stateno_St_Obstacleedge1_straight;
  int dir_St_Obstacleedge1_straight;
  int v_r_St_Obstacleedge1_straight;
  int v_l_St_Obstacleedge1_straight;
  int nr_St_Obstacleedge1;
  Line_follower__st ns_St_Obstacleedge1;
  int time_St_Obstacleedge1;
  int stateno_St_Obstacleedge1;
  int dir_St_Obstacleedge1;
  int v_r_St_Obstacleedge1;
  int v_l_St_Obstacleedge1;
  int nr_St_Blackpath2;
  Line_follower__st ns_St_Blackpath2;
  int time_St_Blackpath2;
  int stateno_St_Blackpath2;
  int dir_St_Blackpath2;
  int v_r_St_Blackpath2;
  int v_l_St_Blackpath2;
  int nr_St_Blackjunction2;
  Line_follower__st ns_St_Blackjunction2;
  int time_St_Blackjunction2;
  int stateno_St_Blackjunction2;
  int dir_St_Blackjunction2;
  int v_r_St_Blackjunction2;
  int v_l_St_Blackjunction2;
  int nr_St_Blackpath1;
  Line_follower__st ns_St_Blackpath1;
  int time_St_Blackpath1;
  int stateno_St_Blackpath1;
  int dir_St_Blackpath1;
  int v_r_St_Blackpath1;
  int v_l_St_Blackpath1;
  int nr_St_Blackjunction1;
  Line_follower__st ns_St_Blackjunction1;
  int time_St_Blackjunction1;
  int stateno_St_Blackjunction1;
  int dir_St_Blackjunction1;
  int v_r_St_Blackjunction1;
  int v_l_St_Blackjunction1;
  int nr_St_Whitepath;
  Line_follower__st ns_St_Whitepath;
  int time_St_Whitepath;
  int stateno_St_Whitepath;
  int dir_St_Whitepath;
  int v_r_St_Whitepath;
  int v_l_St_Whitepath;
  int nr_St_Zstartstate;
  Line_follower__st ns_St_Zstartstate;
  int time_St_Zstartstate;
  int stateno_St_Zstartstate;
  int dir_St_Zstartstate;
  int v_r_St_Zstartstate;
  int v_l_St_Zstartstate;
  Line_follower__st ck_1;
  int v_23;
  int v_22;
  int v_21;
  int v_20;
  int v_19;
  int v_18;
  int v_17;
  int v_16;
  int v_13;
  int v_12;
  int v_11;
  int v_10;
  int v_9;
  int v_8;
  int v_7;
  int v_6;
  int v_5;
  int v_4;
  int v_3;
  int v_2;
  int v;
  Line_follower__st s;
  Line_follower__st ns;
  int r;
  int nr;
  int error;
  int integral;
  int derivative;
  int kp;
  int ki;
  int kd;
  int base_speed;
  int time;
  v_16 = (self->v_15*5);
  v_17 = (v_16/10);
  v_12 = sen[4];
  v_13 = (v_12*2);
  v_9 = sen[3];
  v_10 = (v_9*1);
  v_6 = sen[2];
  v_7 = (v_6*0);
  v_3 = sen[1];
  v_4 = (v_3*-1);
  v = sen[0];
  v_2 = (v*-2);
  v_5 = (v_2+v_4);
  v_8 = (v_5+v_7);
  v_11 = (v_8+v_10);
  error = (v_11+v_13);
  derivative = (error-self->error_1);
  v_18 = (v_17+error);
  if (self->v_14) {
    integral = 0;
  } else {
    integral = v_18;
  };
  base_speed = 50;
  kd = 0;
  v_22 = (kd*derivative);
  ki = 0;
  v_20 = (ki*integral);
  kp = 50;
  v_19 = (kp*error);
  v_21 = (v_19+v_20);
  v_23 = (v_21+v_22);
  _out->correction = (v_23/1000);
  switch (self->ck) {
    case Line_follower__St_Zstartstate:
      v_43 = sen[2];
      v_44 = (v_43-50);
      v_40 = sen[4];
      v_38 = sen[3];
      v_36 = sen[1];
      v_35 = sen[0];
      v_37 = (v_35+v_36);
      v_39 = (v_37+v_38);
      v_41 = (v_39+v_40);
      v_42 = (v_41/4);
      v_45 = (v_42<v_44);
      if (v_45) {
        r_St_Zstartstate = true;
        s_St_Zstartstate = Line_follower__St_Whitepath;
      } else {
        r_St_Zstartstate = self->pnr;
        s_St_Zstartstate = Line_follower__St_Zstartstate;
      };
      s = s_St_Zstartstate;
      r = r_St_Zstartstate;
      break;
    case Line_follower__St_Whitepath:
      v_32 = sen[3];
      v_33 = (v_32>350);
      v_29 = sen[2];
      v_30 = (v_29>350);
      v_26 = sen[1];
      v_27 = (v_26>350);
      v_28 = (line_switch&&v_27);
      v_31 = (v_28&&v_30);
      v_34 = (v_31&&v_33);
      if (v_34) {
        r_St_Whitepath = true;
        s_St_Whitepath = Line_follower__St_Blackjunction1;
      } else {
        r_St_Whitepath = self->pnr;
        s_St_Whitepath = Line_follower__St_Whitepath;
      };
      s = s_St_Whitepath;
      r = r_St_Whitepath;
      break;
    case Line_follower__St_Blackjunction1:
      r_St_Blackjunction1 = self->pnr;
      s_St_Blackjunction1 = Line_follower__St_Blackjunction1;
      s = s_St_Blackjunction1;
      r = r_St_Blackjunction1;
      break;
    case Line_follower__St_Blackpath1:
      r_St_Blackpath1 = self->pnr;
      s_St_Blackpath1 = Line_follower__St_Blackpath1;
      s = s_St_Blackpath1;
      r = r_St_Blackpath1;
      break;
    case Line_follower__St_Blackjunction2:
      r_St_Blackjunction2 = self->pnr;
      s_St_Blackjunction2 = Line_follower__St_Blackjunction2;
      s = s_St_Blackjunction2;
      r = r_St_Blackjunction2;
      break;
    case Line_follower__St_Blackpath2:
      r_St_Blackpath2 = self->pnr;
      s_St_Blackpath2 = Line_follower__St_Blackpath2;
      s = s_St_Blackpath2;
      r = r_St_Blackpath2;
      break;
    case Line_follower__St_Obstacleedge1:
      r_St_Obstacleedge1 = self->pnr;
      s_St_Obstacleedge1 = Line_follower__St_Obstacleedge1;
      s = s_St_Obstacleedge1;
      r = r_St_Obstacleedge1;
      break;
    case Line_follower__St_Obstacleedge1_straight:
      r_St_Obstacleedge1_straight = self->pnr;
      s_St_Obstacleedge1_straight = Line_follower__St_Obstacleedge1_straight;
      s = s_St_Obstacleedge1_straight;
      r = r_St_Obstacleedge1_straight;
      break;
    case Line_follower__St_Obstacleedge2:
      r_St_Obstacleedge2 = self->pnr;
      s_St_Obstacleedge2 = Line_follower__St_Obstacleedge2;
      s = s_St_Obstacleedge2;
      r = r_St_Obstacleedge2;
      break;
    case Line_follower__St_Obstacleedge2_straight:
      r_St_Obstacleedge2_straight = self->pnr;
      s_St_Obstacleedge2_straight = Line_follower__St_Obstacleedge2_straight;
      s = s_St_Obstacleedge2_straight;
      r = r_St_Obstacleedge2_straight;
      break;
    case Line_follower__St_Obstacleedge3:
      r_St_Obstacleedge3 = self->pnr;
      s_St_Obstacleedge3 = Line_follower__St_Obstacleedge3;
      s = s_St_Obstacleedge3;
      r = r_St_Obstacleedge3;
      break;
    case Line_follower__St_Obstacle3_turn1:
      r_St_Obstacle3_turn1 = self->pnr;
      s_St_Obstacle3_turn1 = Line_follower__St_Obstacle3_turn1;
      s = s_St_Obstacle3_turn1;
      r = r_St_Obstacle3_turn1;
      break;
    case Line_follower__St_Obstacle3_straight:
      v_24 = !(ir3);
      v_25 = (ir2&&v_24);
      if (v_25) {
        r_St_Obstacle3_straight = true;
        s_St_Obstacle3_straight = Line_follower__St_Revertfromobstacle;
      } else {
        r_St_Obstacle3_straight = self->pnr;
        s_St_Obstacle3_straight = Line_follower__St_Obstacle3_straight;
      };
      s = s_St_Obstacle3_straight;
      r = r_St_Obstacle3_straight;
      break;
    case Line_follower__St_Revertfromobstacle:
      r_St_Revertfromobstacle = self->pnr;
      s_St_Revertfromobstacle = Line_follower__St_Revertfromobstacle;
      s = s_St_Revertfromobstacle;
      r = r_St_Revertfromobstacle;
      break;
    case Line_follower__St_Blackpath_afterobstacle:
      r_St_Blackpath_afterobstacle = self->pnr;
      s_St_Blackpath_afterobstacle = Line_follower__St_Blackpath_afterobstacle;
      s = s_St_Blackpath_afterobstacle;
      r = r_St_Blackpath_afterobstacle;
      break;
    case Line_follower__St_Blackjunction3:
      r_St_Blackjunction3 = self->pnr;
      s_St_Blackjunction3 = Line_follower__St_Blackjunction3;
      s = s_St_Blackjunction3;
      r = r_St_Blackjunction3;
      break;
    case Line_follower__St_Blackpath3:
      r_St_Blackpath3 = self->pnr;
      s_St_Blackpath3 = Line_follower__St_Blackpath3;
      s = s_St_Blackpath3;
      r = r_St_Blackpath3;
      break;
    case Line_follower__St_Blackjunction4:
      r_St_Blackjunction4 = self->pnr;
      s_St_Blackjunction4 = Line_follower__St_Blackjunction4;
      s = s_St_Blackjunction4;
      r = r_St_Blackjunction4;
      break;
    case Line_follower__St_ParkingPath:
      r_St_ParkingPath = self->pnr;
      s_St_ParkingPath = Line_follower__St_ParkingPath;
      s = s_St_ParkingPath;
      r = r_St_ParkingPath;
      break;
    case Line_follower__St_ParkingOccupied:
      r_St_ParkingOccupied = self->pnr;
      s_St_ParkingOccupied = Line_follower__St_ParkingOccupied;
      s = s_St_ParkingOccupied;
      r = r_St_ParkingOccupied;
      break;
    case Line_follower__St_FreePlace:
      r_St_FreePlace = self->pnr;
      s_St_FreePlace = Line_follower__St_FreePlace;
      s = s_St_FreePlace;
      r = r_St_FreePlace;
      break;
    case Line_follower__St_Stop:
      r_St_Stop = self->pnr;
      s_St_Stop = Line_follower__St_Stop;
      s = s_St_Stop;
      r = r_St_Stop;
      break;
    default:
      break;
  };
  ck_1 = s;
  switch (ck_1) {
    case Line_follower__St_Zstartstate:
      time_St_Zstartstate = 0;
      stateno_St_Zstartstate = 0;
      v_l_St_Zstartstate = base_speed;
      v_r_St_Zstartstate = base_speed;
      dir_St_Zstartstate = 1;
      nr_St_Zstartstate = false;
      ns_St_Zstartstate = Line_follower__St_Zstartstate;
      _out->v_l = v_l_St_Zstartstate;
      _out->v_r = v_r_St_Zstartstate;
      _out->dir = dir_St_Zstartstate;
      _out->stateno = stateno_St_Zstartstate;
      time = time_St_Zstartstate;
      ns = ns_St_Zstartstate;
      nr = nr_St_Zstartstate;
      break;
    case Line_follower__St_Whitepath:
      time_St_Whitepath = 0;
      stateno_St_Whitepath = 1;
      v_287 = (2*_out->correction);
      v_288 = (base_speed+v_287);
      Line_follower__abs_step(v_288, &Line_follower__abs_out_st);
      v_289 = Line_follower__abs_out_st.b;
      v_286 = (base_speed+_out->correction);
      v_285 = (_out->correction>0);
      if (v_285) {
        v_l_St_Whitepath = v_286;
      } else {
        v_l_St_Whitepath = v_289;
      };
      v_284 = (base_speed-_out->correction);
      v_281 = (2*_out->correction);
      v_282 = (base_speed-v_281);
      Line_follower__abs_step(v_282, &Line_follower__abs_out_st);
      v_283 = Line_follower__abs_out_st.b;
      v_280 = (_out->correction>0);
      if (v_280) {
        v_r_St_Whitepath = v_283;
      } else {
        v_r_St_Whitepath = v_284;
      };
      v_276 = (2*_out->correction);
      v_277 = (base_speed+v_276);
      v_278 = (v_277<0);
      if (v_278) {
        v_279 = 2;
      } else {
        v_279 = 1;
      };
      v_273 = (2*_out->correction);
      v_274 = (base_speed-v_273);
      v_275 = (v_274<0);
      if (v_275) {
        dir_St_Whitepath = 3;
      } else {
        dir_St_Whitepath = v_279;
      };
      nr_St_Whitepath = false;
      ns_St_Whitepath = Line_follower__St_Whitepath;
      _out->v_l = v_l_St_Whitepath;
      _out->v_r = v_r_St_Whitepath;
      _out->dir = dir_St_Whitepath;
      _out->stateno = stateno_St_Whitepath;
      time = time_St_Whitepath;
      ns = ns_St_Whitepath;
      nr = nr_St_Whitepath;
      break;
    case Line_follower__St_Blackjunction1:
      v_272 = (self->v_271-1);
      if (self->v_269) {
        v_270 = true;
      } else {
        v_270 = r;
      };
      if (v_270) {
        time_St_Blackjunction1 = 50;
      } else {
        time_St_Blackjunction1 = v_272;
      };
      stateno_St_Blackjunction1 = 2;
      dir_St_Blackjunction1 = 3;
      v_r_St_Blackjunction1 = 20;
      v_l_St_Blackjunction1 = 60;
      v_266 = sen[3];
      v_267 = (v_266<500);
      v_263 = sen[1];
      v_264 = (v_263<500);
      _out->v_l = v_l_St_Blackjunction1;
      _out->v_r = v_r_St_Blackjunction1;
      _out->dir = dir_St_Blackjunction1;
      _out->stateno = stateno_St_Blackjunction1;
      time = time_St_Blackjunction1;
      v_262 = (time<0);
      v_265 = (v_262&&v_264);
      v_268 = (v_265&&v_267);
      if (v_268) {
        nr_St_Blackjunction1 = true;
        ns_St_Blackjunction1 = Line_follower__St_Blackpath1;
      } else {
        nr_St_Blackjunction1 = false;
        ns_St_Blackjunction1 = Line_follower__St_Blackjunction1;
      };
      ns = ns_St_Blackjunction1;
      nr = nr_St_Blackjunction1;
      self->v_271 = time;
      self->v_269 = false;
      break;
    case Line_follower__St_Blackpath1:
      v_261 = (self->v_260-1);
      if (self->v_258) {
        v_259 = true;
      } else {
        v_259 = r;
      };
      if (v_259) {
        time_St_Blackpath1 = 50;
      } else {
        time_St_Blackpath1 = v_261;
      };
      stateno_St_Blackpath1 = 3;
      v_255 = (2*_out->correction);
      v_256 = (base_speed+v_255);
      Line_follower__abs_step(v_256, &Line_follower__abs_out_st);
      v_257 = Line_follower__abs_out_st.b;
      v_254 = (base_speed+_out->correction);
      v_253 = (_out->correction>0);
      if (v_253) {
        v_l_St_Blackpath1 = v_254;
      } else {
        v_l_St_Blackpath1 = v_257;
      };
      v_252 = (base_speed-_out->correction);
      v_249 = (2*_out->correction);
      v_250 = (base_speed-v_249);
      Line_follower__abs_step(v_250, &Line_follower__abs_out_st);
      v_251 = Line_follower__abs_out_st.b;
      v_248 = (_out->correction>0);
      if (v_248) {
        v_r_St_Blackpath1 = v_251;
      } else {
        v_r_St_Blackpath1 = v_252;
      };
      v_244 = (2*_out->correction);
      v_245 = (base_speed+v_244);
      v_246 = (v_245<0);
      if (v_246) {
        v_247 = 2;
      } else {
        v_247 = 1;
      };
      v_241 = (2*_out->correction);
      v_242 = (base_speed-v_241);
      v_243 = (v_242<0);
      if (v_243) {
        dir_St_Blackpath1 = 3;
      } else {
        dir_St_Blackpath1 = v_247;
      };
      v_238 = sen[3];
      v_239 = (v_238>350);
      v_235 = sen[2];
      v_236 = (v_235>350);
      v_232 = sen[1];
      v_233 = (v_232>350);
      _out->v_l = v_l_St_Blackpath1;
      _out->v_r = v_r_St_Blackpath1;
      _out->dir = dir_St_Blackpath1;
      _out->stateno = stateno_St_Blackpath1;
      time = time_St_Blackpath1;
      v_231 = (time<0);
      v_234 = (v_231&&v_233);
      v_237 = (v_234&&v_236);
      v_240 = (v_237&&v_239);
      if (v_240) {
        nr_St_Blackpath1 = true;
        ns_St_Blackpath1 = Line_follower__St_Blackjunction2;
      } else {
        nr_St_Blackpath1 = false;
        ns_St_Blackpath1 = Line_follower__St_Blackpath1;
      };
      ns = ns_St_Blackpath1;
      nr = nr_St_Blackpath1;
      self->v_260 = time;
      self->v_258 = false;
      break;
    case Line_follower__St_Blackjunction2:
      v_230 = (self->v_229-1);
      if (self->v_227) {
        v_228 = true;
      } else {
        v_228 = r;
      };
      if (v_228) {
        time_St_Blackjunction2 = 50;
      } else {
        time_St_Blackjunction2 = v_230;
      };
      stateno_St_Blackjunction2 = 4;
      dir_St_Blackjunction2 = 3;
      v_r_St_Blackjunction2 = 20;
      v_l_St_Blackjunction2 = 60;
      v_224 = sen[3];
      v_225 = (v_224<500);
      v_221 = sen[1];
      v_222 = (v_221<500);
      _out->v_l = v_l_St_Blackjunction2;
      _out->v_r = v_r_St_Blackjunction2;
      _out->dir = dir_St_Blackjunction2;
      _out->stateno = stateno_St_Blackjunction2;
      time = time_St_Blackjunction2;
      v_220 = (time<0);
      v_223 = (v_220&&v_222);
      v_226 = (v_223&&v_225);
      if (v_226) {
        nr_St_Blackjunction2 = true;
        ns_St_Blackjunction2 = Line_follower__St_Blackpath2;
      } else {
        nr_St_Blackjunction2 = false;
        ns_St_Blackjunction2 = Line_follower__St_Blackjunction2;
      };
      ns = ns_St_Blackjunction2;
      nr = nr_St_Blackjunction2;
      self->v_229 = time;
      self->v_227 = false;
      break;
    case Line_follower__St_Blackpath2:
      v_219 = (self->v_218-1);
      if (self->v_216) {
        v_217 = true;
      } else {
        v_217 = r;
      };
      if (v_217) {
        time_St_Blackpath2 = 50;
      } else {
        time_St_Blackpath2 = v_219;
      };
      stateno_St_Blackpath2 = 5;
      v_213 = (2*_out->correction);
      v_214 = (base_speed+v_213);
      Line_follower__abs_step(v_214, &Line_follower__abs_out_st);
      v_215 = Line_follower__abs_out_st.b;
      v_212 = (base_speed+_out->correction);
      v_211 = (_out->correction>0);
      if (v_211) {
        v_l_St_Blackpath2 = v_212;
      } else {
        v_l_St_Blackpath2 = v_215;
      };
      v_210 = (base_speed-_out->correction);
      v_207 = (2*_out->correction);
      v_208 = (base_speed-v_207);
      Line_follower__abs_step(v_208, &Line_follower__abs_out_st);
      v_209 = Line_follower__abs_out_st.b;
      v_206 = (_out->correction>0);
      if (v_206) {
        v_r_St_Blackpath2 = v_209;
      } else {
        v_r_St_Blackpath2 = v_210;
      };
      v_202 = (2*_out->correction);
      v_203 = (base_speed+v_202);
      v_204 = (v_203<0);
      if (v_204) {
        v_205 = 2;
      } else {
        v_205 = 1;
      };
      v_199 = (2*_out->correction);
      v_200 = (base_speed-v_199);
      v_201 = (v_200<0);
      if (v_201) {
        dir_St_Blackpath2 = 3;
      } else {
        dir_St_Blackpath2 = v_205;
      };
      _out->v_l = v_l_St_Blackpath2;
      _out->v_r = v_r_St_Blackpath2;
      _out->dir = dir_St_Blackpath2;
      _out->stateno = stateno_St_Blackpath2;
      time = time_St_Blackpath2;
      v_197 = (time<0);
      v_198 = (v_197&&ir1);
      if (v_198) {
        nr_St_Blackpath2 = true;
        ns_St_Blackpath2 = Line_follower__St_Obstacleedge1;
      } else {
        nr_St_Blackpath2 = false;
        ns_St_Blackpath2 = Line_follower__St_Blackpath2;
      };
      ns = ns_St_Blackpath2;
      nr = nr_St_Blackpath2;
      self->v_218 = time;
      self->v_216 = false;
      break;
    case Line_follower__St_Obstacleedge1:
      time_St_Obstacleedge1 = 0;
      stateno_St_Obstacleedge1 = 6;
      dir_St_Obstacleedge1 = 3;
      v_l_St_Obstacleedge1 = 35;
      v_r_St_Obstacleedge1 = 35;
      v_195 = !(ir3);
      v_196 = (ir2&&v_195);
      if (v_196) {
        nr_St_Obstacleedge1 = true;
        ns_St_Obstacleedge1 = Line_follower__St_Obstacleedge1_straight;
      } else {
        nr_St_Obstacleedge1 = false;
        ns_St_Obstacleedge1 = Line_follower__St_Obstacleedge1;
      };
      _out->v_l = v_l_St_Obstacleedge1;
      _out->v_r = v_r_St_Obstacleedge1;
      _out->dir = dir_St_Obstacleedge1;
      _out->stateno = stateno_St_Obstacleedge1;
      time = time_St_Obstacleedge1;
      ns = ns_St_Obstacleedge1;
      nr = nr_St_Obstacleedge1;
      break;
    case Line_follower__St_Obstacleedge1_straight:
      time_St_Obstacleedge1_straight = 0;
      stateno_St_Obstacleedge1_straight = 7;
      dir_St_Obstacleedge1_straight = 1;
      v_l_St_Obstacleedge1_straight = 30;
      v_r_St_Obstacleedge1_straight = 30;
      v_194 = !(ir2);
      if (v_194) {
        nr_St_Obstacleedge1_straight = true;
        ns_St_Obstacleedge1_straight = Line_follower__St_Obstacleedge2;
      } else {
        nr_St_Obstacleedge1_straight = false;
        ns_St_Obstacleedge1_straight = Line_follower__St_Obstacleedge1_straight;
      };
      _out->v_l = v_l_St_Obstacleedge1_straight;
      _out->v_r = v_r_St_Obstacleedge1_straight;
      _out->dir = dir_St_Obstacleedge1_straight;
      _out->stateno = stateno_St_Obstacleedge1_straight;
      time = time_St_Obstacleedge1_straight;
      ns = ns_St_Obstacleedge1_straight;
      nr = nr_St_Obstacleedge1_straight;
      break;
    case Line_follower__St_Obstacleedge2:
      time_St_Obstacleedge2 = 0;
      stateno_St_Obstacleedge2 = 8;
      dir_St_Obstacleedge2 = 1;
      v_l_St_Obstacleedge2 = 20;
      v_r_St_Obstacleedge2 = 50;
      if (ir0) {
        nr_St_Obstacleedge2 = true;
        ns_St_Obstacleedge2 = Line_follower__St_Obstacleedge2_straight;
      } else {
        nr_St_Obstacleedge2 = false;
        ns_St_Obstacleedge2 = Line_follower__St_Obstacleedge2;
      };
      _out->v_l = v_l_St_Obstacleedge2;
      _out->v_r = v_r_St_Obstacleedge2;
      _out->dir = dir_St_Obstacleedge2;
      _out->stateno = stateno_St_Obstacleedge2;
      time = time_St_Obstacleedge2;
      ns = ns_St_Obstacleedge2;
      nr = nr_St_Obstacleedge2;
      break;
    case Line_follower__St_Obstacleedge2_straight:
      time_St_Obstacleedge2_straight = 0;
      stateno_St_Obstacleedge2_straight = 9;
      dir_St_Obstacleedge2_straight = 3;
      v_r_St_Obstacleedge2_straight = 35;
      v_l_St_Obstacleedge2_straight = 35;
      v_192 = !(ir3);
      v_193 = (ir2&&v_192);
      if (v_193) {
        nr_St_Obstacleedge2_straight = true;
        ns_St_Obstacleedge2_straight = Line_follower__St_Obstacleedge3;
      } else {
        nr_St_Obstacleedge2_straight = false;
        ns_St_Obstacleedge2_straight = Line_follower__St_Obstacleedge2_straight;
      };
      _out->v_l = v_l_St_Obstacleedge2_straight;
      _out->v_r = v_r_St_Obstacleedge2_straight;
      _out->dir = dir_St_Obstacleedge2_straight;
      _out->stateno = stateno_St_Obstacleedge2_straight;
      time = time_St_Obstacleedge2_straight;
      ns = ns_St_Obstacleedge2_straight;
      nr = nr_St_Obstacleedge2_straight;
      break;
    case Line_follower__St_Obstacleedge3:
      time_St_Obstacleedge3 = 0;
      stateno_St_Obstacleedge3 = 10;
      dir_St_Obstacleedge3 = 1;
      v_l_St_Obstacleedge3 = 30;
      v_r_St_Obstacleedge3 = 33;
      v_191 = !(ir2);
      if (v_191) {
        nr_St_Obstacleedge3 = true;
        ns_St_Obstacleedge3 = Line_follower__St_Obstacle3_turn1;
      } else {
        nr_St_Obstacleedge3 = false;
        ns_St_Obstacleedge3 = Line_follower__St_Obstacleedge3;
      };
      _out->v_l = v_l_St_Obstacleedge3;
      _out->v_r = v_r_St_Obstacleedge3;
      _out->dir = dir_St_Obstacleedge3;
      _out->stateno = stateno_St_Obstacleedge3;
      time = time_St_Obstacleedge3;
      ns = ns_St_Obstacleedge3;
      nr = nr_St_Obstacleedge3;
      break;
    case Line_follower__St_Obstacle3_turn1:
      time_St_Obstacle3_turn1 = 0;
      stateno_St_Obstacle3_turn1 = 11;
      dir_St_Obstacle3_turn1 = 1;
      v_l_St_Obstacle3_turn1 = 20;
      v_r_St_Obstacle3_turn1 = 50;
      if (ir0) {
        nr_St_Obstacle3_turn1 = true;
        ns_St_Obstacle3_turn1 = Line_follower__St_Obstacle3_straight;
      } else {
        nr_St_Obstacle3_turn1 = false;
        ns_St_Obstacle3_turn1 = Line_follower__St_Obstacle3_turn1;
      };
      _out->v_l = v_l_St_Obstacle3_turn1;
      _out->v_r = v_r_St_Obstacle3_turn1;
      _out->dir = dir_St_Obstacle3_turn1;
      _out->stateno = stateno_St_Obstacle3_turn1;
      time = time_St_Obstacle3_turn1;
      ns = ns_St_Obstacle3_turn1;
      nr = nr_St_Obstacle3_turn1;
      break;
    case Line_follower__St_Obstacle3_straight:
      time_St_Obstacle3_straight = 0;
      stateno_St_Obstacle3_straight = 16;
      dir_St_Obstacle3_straight = 3;
      v_r_St_Obstacle3_straight = 35;
      v_l_St_Obstacle3_straight = 35;
      nr_St_Obstacle3_straight = false;
      ns_St_Obstacle3_straight = Line_follower__St_Obstacle3_straight;
      _out->v_l = v_l_St_Obstacle3_straight;
      _out->v_r = v_r_St_Obstacle3_straight;
      _out->dir = dir_St_Obstacle3_straight;
      _out->stateno = stateno_St_Obstacle3_straight;
      time = time_St_Obstacle3_straight;
      ns = ns_St_Obstacle3_straight;
      nr = nr_St_Obstacle3_straight;
      break;
    case Line_follower__St_Revertfromobstacle:
      time_St_Revertfromobstacle = 0;
      stateno_St_Revertfromobstacle = 12;
      dir_St_Revertfromobstacle = 1;
      v_l_St_Revertfromobstacle = 40;
      v_r_St_Revertfromobstacle = 30;
      v_189 = sen[2];
      v_190 = (v_189>350);
      if (v_190) {
        nr_St_Revertfromobstacle = true;
        ns_St_Revertfromobstacle = Line_follower__St_Blackpath_afterobstacle;
      } else {
        nr_St_Revertfromobstacle = false;
        ns_St_Revertfromobstacle = Line_follower__St_Revertfromobstacle;
      };
      _out->v_l = v_l_St_Revertfromobstacle;
      _out->v_r = v_r_St_Revertfromobstacle;
      _out->dir = dir_St_Revertfromobstacle;
      _out->stateno = stateno_St_Revertfromobstacle;
      time = time_St_Revertfromobstacle;
      ns = ns_St_Revertfromobstacle;
      nr = nr_St_Revertfromobstacle;
      break;
    case Line_follower__St_Blackpath_afterobstacle:
      v_188 = (self->v_187-1);
      if (self->v_185) {
        v_186 = true;
      } else {
        v_186 = r;
      };
      if (v_186) {
        time_St_Blackpath_afterobstacle = 50;
      } else {
        time_St_Blackpath_afterobstacle = v_188;
      };
      stateno_St_Blackpath_afterobstacle = 13;
      v_182 = (2*_out->correction);
      v_183 = (base_speed+v_182);
      Line_follower__abs_step(v_183, &Line_follower__abs_out_st);
      v_184 = Line_follower__abs_out_st.b;
      v_181 = (base_speed+_out->correction);
      v_180 = (_out->correction>0);
      if (v_180) {
        v_l_St_Blackpath_afterobstacle = v_181;
      } else {
        v_l_St_Blackpath_afterobstacle = v_184;
      };
      v_179 = (base_speed-_out->correction);
      v_176 = (2*_out->correction);
      v_177 = (base_speed-v_176);
      Line_follower__abs_step(v_177, &Line_follower__abs_out_st);
      v_178 = Line_follower__abs_out_st.b;
      v_175 = (_out->correction>0);
      if (v_175) {
        v_r_St_Blackpath_afterobstacle = v_178;
      } else {
        v_r_St_Blackpath_afterobstacle = v_179;
      };
      v_171 = (2*_out->correction);
      v_172 = (base_speed+v_171);
      v_173 = (v_172<0);
      if (v_173) {
        v_174 = 2;
      } else {
        v_174 = 1;
      };
      v_168 = (2*_out->correction);
      v_169 = (base_speed-v_168);
      v_170 = (v_169<0);
      if (v_170) {
        dir_St_Blackpath_afterobstacle = 3;
      } else {
        dir_St_Blackpath_afterobstacle = v_174;
      };
      v_165 = sen[3];
      v_166 = (v_165>250);
      v_162 = sen[2];
      v_163 = (v_162>250);
      v_159 = sen[1];
      v_160 = (v_159>250);
      _out->v_l = v_l_St_Blackpath_afterobstacle;
      _out->v_r = v_r_St_Blackpath_afterobstacle;
      _out->dir = dir_St_Blackpath_afterobstacle;
      _out->stateno = stateno_St_Blackpath_afterobstacle;
      time = time_St_Blackpath_afterobstacle;
      v_158 = (time<0);
      v_161 = (v_158&&v_160);
      v_164 = (v_161&&v_163);
      v_167 = (v_164&&v_166);
      if (v_167) {
        nr_St_Blackpath_afterobstacle = true;
        ns_St_Blackpath_afterobstacle = Line_follower__St_Blackjunction3;
      } else {
        nr_St_Blackpath_afterobstacle = false;
        ns_St_Blackpath_afterobstacle = Line_follower__St_Blackpath_afterobstacle;
      };
      ns = ns_St_Blackpath_afterobstacle;
      nr = nr_St_Blackpath_afterobstacle;
      self->v_187 = time;
      self->v_185 = false;
      break;
    case Line_follower__St_Blackjunction3:
      v_157 = (self->v_156-1);
      if (self->v_154) {
        v_155 = true;
      } else {
        v_155 = r;
      };
      if (v_155) {
        time_St_Blackjunction3 = 50;
      } else {
        time_St_Blackjunction3 = v_157;
      };
      stateno_St_Blackjunction3 = 14;
      dir_St_Blackjunction3 = 2;
      v_r_St_Blackjunction3 = 60;
      v_l_St_Blackjunction3 = 20;
      v_151 = sen[3];
      v_152 = (v_151<500);
      v_148 = sen[1];
      v_149 = (v_148<500);
      _out->v_l = v_l_St_Blackjunction3;
      _out->v_r = v_r_St_Blackjunction3;
      _out->dir = dir_St_Blackjunction3;
      _out->stateno = stateno_St_Blackjunction3;
      time = time_St_Blackjunction3;
      v_147 = (time<0);
      v_150 = (v_147&&v_149);
      v_153 = (v_150&&v_152);
      if (v_153) {
        nr_St_Blackjunction3 = true;
        ns_St_Blackjunction3 = Line_follower__St_Blackpath3;
      } else {
        nr_St_Blackjunction3 = false;
        ns_St_Blackjunction3 = Line_follower__St_Blackjunction3;
      };
      ns = ns_St_Blackjunction3;
      nr = nr_St_Blackjunction3;
      self->v_156 = time;
      self->v_154 = false;
      break;
    case Line_follower__St_Blackpath3:
      v_146 = (self->v_145-1);
      if (self->v_143) {
        v_144 = true;
      } else {
        v_144 = r;
      };
      if (v_144) {
        time_St_Blackpath3 = 50;
      } else {
        time_St_Blackpath3 = v_146;
      };
      stateno_St_Blackpath3 = 15;
      v_140 = (2*_out->correction);
      v_141 = (base_speed+v_140);
      Line_follower__abs_step(v_141, &Line_follower__abs_out_st);
      v_142 = Line_follower__abs_out_st.b;
      v_139 = (base_speed+_out->correction);
      v_138 = (_out->correction>0);
      if (v_138) {
        v_l_St_Blackpath3 = v_139;
      } else {
        v_l_St_Blackpath3 = v_142;
      };
      v_137 = (base_speed-_out->correction);
      v_134 = (2*_out->correction);
      v_135 = (base_speed-v_134);
      Line_follower__abs_step(v_135, &Line_follower__abs_out_st);
      v_136 = Line_follower__abs_out_st.b;
      v_133 = (_out->correction>0);
      if (v_133) {
        v_r_St_Blackpath3 = v_136;
      } else {
        v_r_St_Blackpath3 = v_137;
      };
      v_129 = (2*_out->correction);
      v_130 = (base_speed+v_129);
      v_131 = (v_130<0);
      if (v_131) {
        v_132 = 2;
      } else {
        v_132 = 1;
      };
      v_126 = (2*_out->correction);
      v_127 = (base_speed-v_126);
      v_128 = (v_127<0);
      if (v_128) {
        dir_St_Blackpath3 = 3;
      } else {
        dir_St_Blackpath3 = v_132;
      };
      v_123 = sen[3];
      v_124 = (v_123>350);
      v_120 = sen[2];
      v_121 = (v_120>350);
      v_117 = sen[1];
      v_118 = (v_117>350);
      _out->v_l = v_l_St_Blackpath3;
      _out->v_r = v_r_St_Blackpath3;
      _out->dir = dir_St_Blackpath3;
      _out->stateno = stateno_St_Blackpath3;
      time = time_St_Blackpath3;
      v_116 = (time<0);
      v_119 = (v_116&&v_118);
      v_122 = (v_119&&v_121);
      v_125 = (v_122&&v_124);
      if (v_125) {
        nr_St_Blackpath3 = true;
        ns_St_Blackpath3 = Line_follower__St_Blackjunction4;
      } else {
        nr_St_Blackpath3 = false;
        ns_St_Blackpath3 = Line_follower__St_Blackpath3;
      };
      ns = ns_St_Blackpath3;
      nr = nr_St_Blackpath3;
      self->v_145 = time;
      self->v_143 = false;
      break;
    case Line_follower__St_Blackjunction4:
      v_115 = (self->v_114-1);
      if (self->v_112) {
        v_113 = true;
      } else {
        v_113 = r;
      };
      if (v_113) {
        time_St_Blackjunction4 = 50;
      } else {
        time_St_Blackjunction4 = v_115;
      };
      stateno_St_Blackjunction4 = 16;
      dir_St_Blackjunction4 = 2;
      v_r_St_Blackjunction4 = 60;
      v_l_St_Blackjunction4 = 20;
      v_109 = sen[3];
      v_110 = (v_109<500);
      v_106 = sen[1];
      v_107 = (v_106<500);
      _out->v_l = v_l_St_Blackjunction4;
      _out->v_r = v_r_St_Blackjunction4;
      _out->dir = dir_St_Blackjunction4;
      _out->stateno = stateno_St_Blackjunction4;
      time = time_St_Blackjunction4;
      v_105 = (time<0);
      v_108 = (v_105&&v_107);
      v_111 = (v_108&&v_110);
      if (v_111) {
        nr_St_Blackjunction4 = true;
        ns_St_Blackjunction4 = Line_follower__St_ParkingPath;
      } else {
        nr_St_Blackjunction4 = false;
        ns_St_Blackjunction4 = Line_follower__St_Blackjunction4;
      };
      ns = ns_St_Blackjunction4;
      nr = nr_St_Blackjunction4;
      self->v_114 = time;
      self->v_112 = false;
      break;
    case Line_follower__St_ParkingPath:
      time_St_ParkingPath = 0;
      stateno_St_ParkingPath = 17;
      v_102 = (2*_out->correction);
      v_103 = (base_speed+v_102);
      Line_follower__abs_step(v_103, &Line_follower__abs_out_st);
      v_104 = Line_follower__abs_out_st.b;
      v_101 = (base_speed+_out->correction);
      v_100 = (_out->correction>0);
      if (v_100) {
        v_l_St_ParkingPath = v_101;
      } else {
        v_l_St_ParkingPath = v_104;
      };
      v_99 = (base_speed-_out->correction);
      v_96 = (2*_out->correction);
      v_97 = (base_speed-v_96);
      Line_follower__abs_step(v_97, &Line_follower__abs_out_st);
      v_98 = Line_follower__abs_out_st.b;
      v_95 = (_out->correction>0);
      if (v_95) {
        v_r_St_ParkingPath = v_98;
      } else {
        v_r_St_ParkingPath = v_99;
      };
      v_91 = (2*_out->correction);
      v_92 = (base_speed+v_91);
      v_93 = (v_92<0);
      if (v_93) {
        v_94 = 2;
      } else {
        v_94 = 1;
      };
      v_88 = (2*_out->correction);
      v_89 = (base_speed-v_88);
      v_90 = (v_89<0);
      if (v_90) {
        dir_St_ParkingPath = 3;
      } else {
        dir_St_ParkingPath = v_94;
      };
      v_87 = (ir2||ir4);
      if (v_87) {
        nr_St_ParkingPath = true;
        ns_St_ParkingPath = Line_follower__St_ParkingOccupied;
      } else {
        nr_St_ParkingPath = false;
        ns_St_ParkingPath = Line_follower__St_ParkingPath;
      };
      _out->v_l = v_l_St_ParkingPath;
      _out->v_r = v_r_St_ParkingPath;
      _out->dir = dir_St_ParkingPath;
      _out->stateno = stateno_St_ParkingPath;
      time = time_St_ParkingPath;
      ns = ns_St_ParkingPath;
      nr = nr_St_ParkingPath;
      break;
    case Line_follower__St_ParkingOccupied:
      time_St_ParkingOccupied = 0;
      stateno_St_ParkingOccupied = 25;
      v_84 = (2*_out->correction);
      v_85 = (base_speed+v_84);
      Line_follower__abs_step(v_85, &Line_follower__abs_out_st);
      v_86 = Line_follower__abs_out_st.b;
      v_83 = (base_speed+_out->correction);
      v_82 = (_out->correction>0);
      if (v_82) {
        v_l_St_ParkingOccupied = v_83;
      } else {
        v_l_St_ParkingOccupied = v_86;
      };
      v_81 = (base_speed-_out->correction);
      v_78 = (2*_out->correction);
      v_79 = (base_speed-v_78);
      Line_follower__abs_step(v_79, &Line_follower__abs_out_st);
      v_80 = Line_follower__abs_out_st.b;
      v_77 = (_out->correction>0);
      if (v_77) {
        v_r_St_ParkingOccupied = v_80;
      } else {
        v_r_St_ParkingOccupied = v_81;
      };
      v_73 = (2*_out->correction);
      v_74 = (base_speed+v_73);
      v_75 = (v_74<0);
      if (v_75) {
        v_76 = 2;
      } else {
        v_76 = 1;
      };
      v_70 = (2*_out->correction);
      v_71 = (base_speed-v_70);
      v_72 = (v_71<0);
      if (v_72) {
        dir_St_ParkingOccupied = 3;
      } else {
        dir_St_ParkingOccupied = v_76;
      };
      v_68 = !(ir0);
      v_66 = !(ir1);
      v_64 = !(ir3);
      v_62 = !(ir4);
      v_61 = !(ir2);
      v_63 = (v_61&&v_62);
      v_65 = (v_63&&v_64);
      v_67 = (v_65&&v_66);
      v_69 = (v_67&&v_68);
      if (v_69) {
        nr_St_ParkingOccupied = true;
        ns_St_ParkingOccupied = Line_follower__St_FreePlace;
      } else {
        nr_St_ParkingOccupied = false;
        ns_St_ParkingOccupied = Line_follower__St_ParkingOccupied;
      };
      _out->v_l = v_l_St_ParkingOccupied;
      _out->v_r = v_r_St_ParkingOccupied;
      _out->dir = dir_St_ParkingOccupied;
      _out->stateno = stateno_St_ParkingOccupied;
      time = time_St_ParkingOccupied;
      ns = ns_St_ParkingOccupied;
      nr = nr_St_ParkingOccupied;
      break;
    case Line_follower__St_FreePlace:
      time_St_FreePlace = 0;
      stateno_St_FreePlace = 25;
      dir_St_FreePlace = 1;
      v_r_St_FreePlace = 50;
      v_l_St_FreePlace = 20;
      v_58 = sen[4];
      v_59 = (v_58<400);
      v_55 = sen[3];
      v_56 = (v_55<400);
      v_52 = sen[2];
      v_53 = (v_52<400);
      v_49 = sen[1];
      v_46 = sen[0];
      v_50 = (v_49<400);
      v_47 = (v_46<400);
      v_48 = (ir3&&v_47);
      v_51 = (v_48&&v_50);
      v_54 = (v_51&&v_53);
      v_57 = (v_54&&v_56);
      v_60 = (v_57&&v_59);
      if (v_60) {
        nr_St_FreePlace = true;
        ns_St_FreePlace = Line_follower__St_Stop;
      } else {
        nr_St_FreePlace = false;
        ns_St_FreePlace = Line_follower__St_FreePlace;
      };
      _out->v_l = v_l_St_FreePlace;
      _out->v_r = v_r_St_FreePlace;
      _out->dir = dir_St_FreePlace;
      _out->stateno = stateno_St_FreePlace;
      time = time_St_FreePlace;
      ns = ns_St_FreePlace;
      nr = nr_St_FreePlace;
      break;
    case Line_follower__St_Stop:
      time_St_Stop = 0;
      stateno_St_Stop = 25;
      dir_St_Stop = 1;
      v_r_St_Stop = 0;
      v_l_St_Stop = 0;
      nr_St_Stop = false;
      ns_St_Stop = Line_follower__St_Stop;
      _out->v_l = v_l_St_Stop;
      _out->v_r = v_r_St_Stop;
      _out->dir = dir_St_Stop;
      _out->stateno = stateno_St_Stop;
      time = time_St_Stop;
      ns = ns_St_Stop;
      nr = nr_St_Stop;
      break;
    default:
      break;
  };
  self->error_1 = error;
  self->pnr = nr;
  self->ck = ns;
  self->v_15 = integral;
  self->v_14 = false;;
}

void Line_follower__main_reset(Line_follower__main_mem* self) {
  Line_follower__line_follower_reset(&self->line_follower);
  self->v_293 = true;
}

void Line_follower__main_step(int sen0, int sen1, int sen2, int sen3,
                              int sen4, int ir0, int ir1, int ir2, int ir3,
                              int ir4, Line_follower__main_out* _out,
                              Line_follower__main_mem* self) {
  Line_follower__line_follower_out Line_follower__line_follower_out_st;
  
  int v_303[5];
  int v_302[5];
  int v_301;
  int v_300;
  int v_299;
  int v_298;
  int v_297;
  int v_296;
  int v_295;
  int v_292;
  int v_291;
  int v_290;
  int v;
  int out[5];
  v_301 = (1023-sen4);
  v_300 = (1023-sen3);
  v_299 = (1023-sen2);
  v_298 = (1023-sen1);
  v_297 = (1023-sen0);
  v_292 = (4*sen2);
  v = (sen0+sen1);
  v_290 = (v+sen4);
  v_291 = (v_290+sen3);
  _out->err = (v_291-v_292);
  v_295 = (_out->err>1000);
  v_296 = (self->v_294||v_295);
  if (self->v_293) {
    _out->line_switch = false;
  } else {
    _out->line_switch = v_296;
  };
  v_303[0] = sen0;
  v_303[1] = sen1;
  v_303[2] = sen2;
  v_303[3] = sen3;
  v_303[4] = sen4;
  v_302[0] = v_297;
  v_302[1] = v_298;
  v_302[2] = v_299;
  v_302[3] = v_300;
  v_302[4] = v_301;
  if (_out->line_switch) {
    {
      int _1;
      for (_1 = 0; _1 < 5; ++_1) {
        out[_1] = v_302[_1];
      }
    };
  } else {
    {
      int _2;
      for (_2 = 0; _2 < 5; ++_2) {
        out[_2] = v_303[_2];
      }
    };
  };
  Line_follower__line_follower_step(out, ir0, ir1, ir2, ir3, ir4,
                                    _out->line_switch,
                                    &Line_follower__line_follower_out_st,
                                    &self->line_follower);
  _out->v_l = Line_follower__line_follower_out_st.v_l;
  _out->v_r = Line_follower__line_follower_out_st.v_r;
  _out->dir = Line_follower__line_follower_out_st.dir;
  _out->correction = Line_follower__line_follower_out_st.correction;
  _out->stateno = Line_follower__line_follower_out_st.stateno;
  self->v_294 = _out->line_switch;
  self->v_293 = false;;
}

