/* --- Generated the 9/4/2025 at 2:51 --- */
/* --- heptagon compiler, version 1.05.00 (compiled wed. mar. 19 17:12:18 CET 2025) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts line_follower.ept --- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "line_follower_types.h"

Line_follower__st Line_follower__st_of_string(char* s) {
  if ((strcmp(s, "St_Zstartstate")==0)) {
    return Line_follower__St_Zstartstate;
  };
  if ((strcmp(s, "St_Whitepath")==0)) {
    return Line_follower__St_Whitepath;
  };
  if ((strcmp(s, "St_Stop")==0)) {
    return Line_follower__St_Stop;
  };
  if ((strcmp(s, "St_Revertfromobstacle")==0)) {
    return Line_follower__St_Revertfromobstacle;
  };
  if ((strcmp(s, "St_ParkingPath")==0)) {
    return Line_follower__St_ParkingPath;
  };
  if ((strcmp(s, "St_ParkingOccupied")==0)) {
    return Line_follower__St_ParkingOccupied;
  };
  if ((strcmp(s, "St_Obstacleedge3")==0)) {
    return Line_follower__St_Obstacleedge3;
  };
  if ((strcmp(s, "St_Obstacleedge2_straight")==0)) {
    return Line_follower__St_Obstacleedge2_straight;
  };
  if ((strcmp(s, "St_Obstacleedge2")==0)) {
    return Line_follower__St_Obstacleedge2;
  };
  if ((strcmp(s, "St_Obstacleedge1_straight")==0)) {
    return Line_follower__St_Obstacleedge1_straight;
  };
  if ((strcmp(s, "St_Obstacleedge1")==0)) {
    return Line_follower__St_Obstacleedge1;
  };
  if ((strcmp(s, "St_Obstacle3_turn1")==0)) {
    return Line_follower__St_Obstacle3_turn1;
  };
  if ((strcmp(s, "St_Obstacle3_straight")==0)) {
    return Line_follower__St_Obstacle3_straight;
  };
  if ((strcmp(s, "St_FreePlace")==0)) {
    return Line_follower__St_FreePlace;
  };
  if ((strcmp(s, "St_Blackpath_afterobstacle")==0)) {
    return Line_follower__St_Blackpath_afterobstacle;
  };
  if ((strcmp(s, "St_Blackpath3")==0)) {
    return Line_follower__St_Blackpath3;
  };
  if ((strcmp(s, "St_Blackpath2")==0)) {
    return Line_follower__St_Blackpath2;
  };
  if ((strcmp(s, "St_Blackpath1")==0)) {
    return Line_follower__St_Blackpath1;
  };
  if ((strcmp(s, "St_Blackjunction4")==0)) {
    return Line_follower__St_Blackjunction4;
  };
  if ((strcmp(s, "St_Blackjunction3")==0)) {
    return Line_follower__St_Blackjunction3;
  };
  if ((strcmp(s, "St_Blackjunction2")==0)) {
    return Line_follower__St_Blackjunction2;
  };
  if ((strcmp(s, "St_Blackjunction1")==0)) {
    return Line_follower__St_Blackjunction1;
  };
}

char* string_of_Line_follower__st(Line_follower__st x, char* buf) {
  switch (x) {
    case Line_follower__St_Zstartstate:
      strcpy(buf, "St_Zstartstate");
      break;
    case Line_follower__St_Whitepath:
      strcpy(buf, "St_Whitepath");
      break;
    case Line_follower__St_Stop:
      strcpy(buf, "St_Stop");
      break;
    case Line_follower__St_Revertfromobstacle:
      strcpy(buf, "St_Revertfromobstacle");
      break;
    case Line_follower__St_ParkingPath:
      strcpy(buf, "St_ParkingPath");
      break;
    case Line_follower__St_ParkingOccupied:
      strcpy(buf, "St_ParkingOccupied");
      break;
    case Line_follower__St_Obstacleedge3:
      strcpy(buf, "St_Obstacleedge3");
      break;
    case Line_follower__St_Obstacleedge2_straight:
      strcpy(buf, "St_Obstacleedge2_straight");
      break;
    case Line_follower__St_Obstacleedge2:
      strcpy(buf, "St_Obstacleedge2");
      break;
    case Line_follower__St_Obstacleedge1_straight:
      strcpy(buf, "St_Obstacleedge1_straight");
      break;
    case Line_follower__St_Obstacleedge1:
      strcpy(buf, "St_Obstacleedge1");
      break;
    case Line_follower__St_Obstacle3_turn1:
      strcpy(buf, "St_Obstacle3_turn1");
      break;
    case Line_follower__St_Obstacle3_straight:
      strcpy(buf, "St_Obstacle3_straight");
      break;
    case Line_follower__St_FreePlace:
      strcpy(buf, "St_FreePlace");
      break;
    case Line_follower__St_Blackpath_afterobstacle:
      strcpy(buf, "St_Blackpath_afterobstacle");
      break;
    case Line_follower__St_Blackpath3:
      strcpy(buf, "St_Blackpath3");
      break;
    case Line_follower__St_Blackpath2:
      strcpy(buf, "St_Blackpath2");
      break;
    case Line_follower__St_Blackpath1:
      strcpy(buf, "St_Blackpath1");
      break;
    case Line_follower__St_Blackjunction4:
      strcpy(buf, "St_Blackjunction4");
      break;
    case Line_follower__St_Blackjunction3:
      strcpy(buf, "St_Blackjunction3");
      break;
    case Line_follower__St_Blackjunction2:
      strcpy(buf, "St_Blackjunction2");
      break;
    case Line_follower__St_Blackjunction1:
      strcpy(buf, "St_Blackjunction1");
      break;
    default:
      break;
  };
  return buf;
}

