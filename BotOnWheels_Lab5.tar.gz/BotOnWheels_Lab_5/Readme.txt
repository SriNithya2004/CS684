https://youtu.be/7Wl812W9R_E?si=lbZT9kA3yYXy9XD4


No where the bot collided, be it obstacle or the parking hurdles
No manual Interventions

We followed all video instructions