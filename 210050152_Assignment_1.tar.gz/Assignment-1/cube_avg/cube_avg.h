typedef struct memory {
    double sum_of_cubes;
    int count;
} memory;

typedef struct out {
    double out;
} out;

void reset(memory* self);

void step(int x, out* _out, memory* self);


