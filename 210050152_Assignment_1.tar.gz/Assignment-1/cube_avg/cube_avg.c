#include <stdio.h>
#include "cube_avg.h"

void reset(memory* self) {
    self->sum_of_cubes = 0;
    self->count = 0;
}

void step(int x, out* _out, memory* self) {
    double cube = x*x*x;
    self->sum_of_cubes = cube + self->sum_of_cubes;
    self->count = self->count +1;
    _out->out = self->sum_of_cubes / self->count;
}