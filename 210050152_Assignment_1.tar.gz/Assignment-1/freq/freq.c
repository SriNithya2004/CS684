#include <stdio.h>
#include "freq.h"

void reset(memory* self) {
    self->first=1;
}

void step(int x, out* _out, memory* self) {
    if(self->first){
        self->our_number=x;
        self->our_number_freq=1;
        self->first = 0;
    }
    else{
        if(x==self->our_number){
            self->our_number_freq=self->our_number_freq+1;
        }
    }
    _out->out=self->our_number_freq;
}


