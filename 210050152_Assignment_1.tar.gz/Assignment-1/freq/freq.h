typedef struct memory {
    int our_number_freq;
    int our_number;
    int first;
} memory;

typedef struct out {
    int out;
} out;

void reset(memory* self);

void step(int x, out* _out, memory* self);
