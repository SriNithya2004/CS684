/* --- Generated the 28/3/2025 at 6:36 --- */
/* --- heptagon compiler, version 1.05.00 (compiled thu. mar. 20 22:35:38 CET 2025) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts obstacle_navigation.ept --- */

#ifndef OBSTACLE_NAVIGATION_H
#define OBSTACLE_NAVIGATION_H

#include "obstacle_navigation_types.h"
typedef struct Obstacle_navigation__black_check_out {
  long out;
} Obstacle_navigation__black_check_out;

void Obstacle_navigation__black_check_step(long sen0, long sen1, long sen2,
                                           long sen3, long sen4,
                                           Obstacle_navigation__black_check_out* _out);

typedef struct Obstacle_navigation__main_mem {
  long v_32;
  long v_28;
  long v_24;
  long v;
} Obstacle_navigation__main_mem;

typedef struct Obstacle_navigation__main_out {
  long mode;
  long v_l;
  long v_r;
} Obstacle_navigation__main_out;

void Obstacle_navigation__main_reset(Obstacle_navigation__main_mem* self);

void Obstacle_navigation__main_step(long sen0, long sen1, long sen2, long sen3,
                                    long sen4, long ir0, long ir1, long ir2,
                                    Obstacle_navigation__main_out* _out,
                                    Obstacle_navigation__main_mem* self);

#endif // OBSTACLE_NAVIGATION_H
