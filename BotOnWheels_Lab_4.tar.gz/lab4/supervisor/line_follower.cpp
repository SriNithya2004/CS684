/* --- Generated the 31/3/2025 at 5:9 --- */
/* --- heptagon compiler, version 1.05.00 (compiled wed. mar. 19 17:12:18 CET 2025) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts line_follower.ept --- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "line_follower.h"

void Line_follower__black_check_step(long sen0, long sen1, long sen2, long sen3,
                                     long sen4,
                                     Line_follower__black_check_out* _out) {
  
  long v_23;
  long v_22;
  long v_21;
  long v_20;
  long v_19;
  long v_18;
  long v_17;
  long v_16;
  long v_15;
  long v_14;
  long v_13;
  long v_12;
  long v_11;
  long v_10;
  long v_9;
  long v_8;
  long v_7;
  long v_6;
  long v_5;
  long v_4;
  long v_3;
  long v_2;
  long v_1;
  long v;
  long avg;
  long param;
  param = 100;
  v = (sen0+sen1);
  v_1 = (v+sen2);
  v_2 = (v_1+sen3);
  v_3 = (v_2+sen4);
  avg = (v_3/5);
  v_20 = (sen4-avg);
  v_19 = (sen4-avg);
  v_21 = (v_19*v_20);
  v_16 = (sen3-avg);
  v_15 = (sen3-avg);
  v_17 = (v_15*v_16);
  v_12 = (sen2-avg);
  v_11 = (sen2-avg);
  v_13 = (v_11*v_12);
  v_8 = (sen1-avg);
  v_7 = (sen1-avg);
  v_9 = (v_7*v_8);
  v_5 = (sen0-avg);
  v_4 = (sen0-avg);
  v_6 = (v_4*v_5);
  v_10 = (v_6+v_9);
  v_14 = (v_10+v_13);
  v_18 = (v_14+v_17);
  v_22 = (v_18+v_21);
  v_23 = (v_22<100);
  if (v_23) {
    _out->out = true;
  } else {
    _out->out = false;
  };;
}

void Line_follower__abs_step(long a, Line_follower__abs_out* _out) {
  
  long v_24;
  long v;
  v_24 = -(a);
  v = (a<0);
  if (v) {
    _out->b = v_24;
  } else {
    _out->b = a;
  };;
}

void Line_follower__line_follower_reset(Line_follower__line_follower_mem* self) {
  self->v_137 = true;
  self->v_106 = true;
  self->error_1 = 0;
  self->pnr = false;
  self->ck = Line_follower__St_ZNormal;
  self->v_37 = true;
}

void Line_follower__line_follower_step(long sen[5], long line_switch, long ir0,
                                       long ir1, long ir2, long ir3,
                                       Line_follower__line_follower_out* _out,
                                       Line_follower__line_follower_mem* self) {
  Line_follower__abs_out Line_follower__abs_out_st;
  
  long v_51;
  long v_50;
  long v_49;
  long v_48;
  long v_47;
  long v_56;
  long v_55;
  long v_54;
  long v_53;
  long v_52;
  long v_61;
  long v_60;
  long v_59;
  long v_58;
  long v_57;
  long v_70;
  long v_69;
  long v_68;
  long v_67;
  long v_66;
  long v_65;
  long v_64;
  long v_63;
  long v_62;
  long r_St_Junction3;
  Line_follower__st s_St_Junction3;
  long r_St_Obstacle6;
  Line_follower__st s_St_Obstacle6;
  long r_St_Obstacle5;
  Line_follower__st s_St_Obstacle5;
  long r_St_Obstacle4;
  Line_follower__st s_St_Obstacle4;
  long r_St_Right;
  Line_follower__st s_St_Right;
  long r_St_Obstacle3;
  Line_follower__st s_St_Obstacle3;
  long r_St_Obstacle2;
  Line_follower__st s_St_Obstacle2;
  long r_St_Obstacle1;
  Line_follower__st s_St_Obstacle1;
  long r_St_Normal3;
  Line_follower__st s_St_Normal3;
  long r_St_Junction2;
  Line_follower__st s_St_Junction2;
  long r_St_Normal2;
  Line_follower__st s_St_Normal2;
  long r_St_Junction1;
  Line_follower__st s_St_Junction1;
  long r_St_ZNormal;
  Line_follower__st s_St_ZNormal;
  long v_72;
  long v_71;
  long v_73;
  long v_74;
  long v_76;
  long v_75;
  long v_109;
  long v_107;
  long v_105;
  long v_104;
  long v_103;
  long v_102;
  long v_101;
  long v_100;
  long v_99;
  long v_98;
  long v_97;
  long v_96;
  long v_95;
  long v_94;
  long v_93;
  long v_92;
  long v_91;
  long v_90;
  long v_89;
  long v_88;
  Line_follower__st v_87;
  long v_86;
  long v_85;
  long v_84;
  long v_83;
  long v_82;
  long v_81;
  long v_80;
  long v_79;
  long v_78;
  long v_77;
  long v_140;
  long v_138;
  long v_136;
  long v_135;
  long v_134;
  long v_133;
  long v_132;
  long v_131;
  long v_130;
  long v_129;
  long v_128;
  long v_127;
  long v_126;
  long v_125;
  long v_124;
  long v_123;
  long v_122;
  long v_121;
  long v_120;
  long v_119;
  long v_118;
  long v_117;
  long v_116;
  long v_115;
  long v_114;
  long v_113;
  long v_112;
  long v_111;
  long v_110;
  long v_166;
  long v_165;
  long v_164;
  long v_163;
  long v_162;
  long v_161;
  long v_160;
  long v_159;
  long v_158;
  long v_157;
  long v_156;
  long v_155;
  long v_154;
  long v_153;
  long v_152;
  long v_151;
  long v_150;
  long v_149;
  long v_148;
  long v_147;
  long v_146;
  long v_145;
  long v_144;
  long v_143;
  long v_142;
  long v_141;
  long nr_St_Junction3;
  Line_follower__st ns_St_Junction3;
  long time_St_Junction3;
  long stateno_St_Junction3;
  long dir_St_Junction3;
  long v_r_St_Junction3;
  long v_l_St_Junction3;
  long nr_St_Obstacle6;
  Line_follower__st ns_St_Obstacle6;
  long time_St_Obstacle6;
  long stateno_St_Obstacle6;
  long dir_St_Obstacle6;
  long v_r_St_Obstacle6;
  long v_l_St_Obstacle6;
  long nr_St_Obstacle5;
  Line_follower__st ns_St_Obstacle5;
  long time_St_Obstacle5;
  long stateno_St_Obstacle5;
  long dir_St_Obstacle5;
  long v_r_St_Obstacle5;
  long v_l_St_Obstacle5;
  long nr_St_Obstacle4;
  Line_follower__st ns_St_Obstacle4;
  long time_St_Obstacle4;
  long stateno_St_Obstacle4;
  long dir_St_Obstacle4;
  long v_r_St_Obstacle4;
  long v_l_St_Obstacle4;
  long nr_St_Right;
  Line_follower__st ns_St_Right;
  long time_St_Right;
  long stateno_St_Right;
  long dir_St_Right;
  long v_r_St_Right;
  long v_l_St_Right;
  long nr_St_Obstacle3;
  Line_follower__st ns_St_Obstacle3;
  long time_St_Obstacle3;
  long stateno_St_Obstacle3;
  long dir_St_Obstacle3;
  long v_r_St_Obstacle3;
  long v_l_St_Obstacle3;
  long nr_St_Obstacle2;
  Line_follower__st ns_St_Obstacle2;
  long time_St_Obstacle2;
  long stateno_St_Obstacle2;
  long dir_St_Obstacle2;
  long v_r_St_Obstacle2;
  long v_l_St_Obstacle2;
  long nr_St_Obstacle1;
  Line_follower__st ns_St_Obstacle1;
  long time_St_Obstacle1;
  long stateno_St_Obstacle1;
  long dir_St_Obstacle1;
  long v_r_St_Obstacle1;
  long v_l_St_Obstacle1;
  long nr_St_Normal3;
  Line_follower__st ns_St_Normal3;
  long time_St_Normal3;
  long stateno_St_Normal3;
  long dir_St_Normal3;
  long v_r_St_Normal3;
  long v_l_St_Normal3;
  long nr_St_Junction2;
  Line_follower__st ns_St_Junction2;
  long time_St_Junction2;
  long stateno_St_Junction2;
  long dir_St_Junction2;
  long v_r_St_Junction2;
  long v_l_St_Junction2;
  long nr_St_Normal2;
  Line_follower__st ns_St_Normal2;
  long time_St_Normal2;
  long stateno_St_Normal2;
  long dir_St_Normal2;
  long v_r_St_Normal2;
  long v_l_St_Normal2;
  long nr_St_Junction1;
  Line_follower__st ns_St_Junction1;
  long time_St_Junction1;
  long stateno_St_Junction1;
  long dir_St_Junction1;
  long v_r_St_Junction1;
  long v_l_St_Junction1;
  long nr_St_ZNormal;
  Line_follower__st ns_St_ZNormal;
  long time_St_ZNormal;
  long stateno_St_ZNormal;
  long dir_St_ZNormal;
  long v_r_St_ZNormal;
  long v_l_St_ZNormal;
  Line_follower__st ck_1;
  long v_46;
  long v_45;
  long v_44;
  long v_43;
  long v_42;
  long v_41;
  long v_40;
  long v_39;
  long v_36;
  long v_35;
  long v_34;
  long v_33;
  long v_32;
  long v_31;
  long v_30;
  long v_29;
  long v_28;
  long v_27;
  long v_26;
  long v_25;
  long v;
  Line_follower__st s;
  Line_follower__st ns;
  long r;
  long nr;
  long error;
  long longegral;
  long derivative;
  long kp;
  long ki;
  long kd;
  long base_speed;
  long time;
  v_39 = (self->v_38*9);
  v_40 = (v_39/10);
  v_35 = sen[4];
  v_36 = (v_35*2);
  v_32 = sen[3];
  v_33 = (v_32*1);
  v_29 = sen[2];
  v_30 = (v_29*0);
  v_26 = sen[1];
  v_27 = (v_26*-1);
  v = sen[0];
  v_25 = (v*-2);
  v_28 = (v_25+v_27);
  v_31 = (v_28+v_30);
  v_34 = (v_31+v_33);
  error = (v_34+v_36);
  derivative = (error-self->error_1);
  v_41 = (v_40+error);
  if (self->v_37) {
    longegral = 0;
  } else {
    longegral = v_41;
  };
  base_speed = 50;
  kd = 20;
  v_45 = (kd*derivative);
  ki = 0;
  v_43 = (ki*longegral);
  kp = 65;
  v_42 = (kp*error);
  v_44 = (v_42+v_43);
  v_46 = (v_44+v_45);
  _out->correction = (v_46/1000);
  switch (self->ck) {
    case Line_follower__St_ZNormal:
      v_68 = sen[3];
      v_69 = (v_68>500);
      v_65 = sen[2];
      v_66 = (v_65>400);
      v_62 = sen[1];
      v_63 = (v_62>500);
      v_64 = (line_switch&&v_63);
      v_67 = (v_64&&v_66);
      v_70 = (v_67&&v_69);
      if (v_70) {
        r_St_ZNormal = true;
        s_St_ZNormal = Line_follower__St_Junction1;
      } else {
        r_St_ZNormal = self->pnr;
        s_St_ZNormal = Line_follower__St_ZNormal;
      };
      s = s_St_ZNormal;
      r = r_St_ZNormal;
      break;
    case Line_follower__St_Junction1:
      v_59 = sen[3];
      v_60 = (v_59<500);
      v_57 = sen[1];
      v_58 = (v_57<500);
      v_61 = (v_58&&v_60);
      if (v_61) {
        r_St_Junction1 = true;
        s_St_Junction1 = Line_follower__St_Normal2;
      } else {
        r_St_Junction1 = self->pnr;
        s_St_Junction1 = Line_follower__St_Junction1;
      };
      s = s_St_Junction1;
      r = r_St_Junction1;
      break;
    case Line_follower__St_Normal2:
      r_St_Normal2 = self->pnr;
      s_St_Normal2 = Line_follower__St_Normal2;
      s = s_St_Normal2;
      r = r_St_Normal2;
      break;
    case Line_follower__St_Junction2:
      v_54 = sen[3];
      v_55 = (v_54<500);
      v_52 = sen[1];
      v_53 = (v_52<500);
      v_56 = (v_53&&v_55);
      if (v_56) {
        r_St_Junction2 = true;
        s_St_Junction2 = Line_follower__St_Normal3;
      } else {
        r_St_Junction2 = self->pnr;
        s_St_Junction2 = Line_follower__St_Junction2;
      };
      s = s_St_Junction2;
      r = r_St_Junction2;
      break;
    case Line_follower__St_Normal3:
      r_St_Normal3 = self->pnr;
      s_St_Normal3 = Line_follower__St_Normal3;
      s = s_St_Normal3;
      r = r_St_Normal3;
      break;
    case Line_follower__St_Obstacle1:
      r_St_Obstacle1 = self->pnr;
      s_St_Obstacle1 = Line_follower__St_Obstacle1;
      s = s_St_Obstacle1;
      r = r_St_Obstacle1;
      break;
    case Line_follower__St_Obstacle2:
      r_St_Obstacle2 = self->pnr;
      s_St_Obstacle2 = Line_follower__St_Obstacle2;
      s = s_St_Obstacle2;
      r = r_St_Obstacle2;
      break;
    case Line_follower__St_Obstacle3:
      r_St_Obstacle3 = self->pnr;
      s_St_Obstacle3 = Line_follower__St_Obstacle3;
      s = s_St_Obstacle3;
      r = r_St_Obstacle3;
      break;
    case Line_follower__St_Right:
      r_St_Right = self->pnr;
      s_St_Right = Line_follower__St_Right;
      s = s_St_Right;
      r = r_St_Right;
      break;
    case Line_follower__St_Obstacle4:
      r_St_Obstacle4 = self->pnr;
      s_St_Obstacle4 = Line_follower__St_Obstacle4;
      s = s_St_Obstacle4;
      r = r_St_Obstacle4;
      break;
    case Line_follower__St_Obstacle5:
      r_St_Obstacle5 = self->pnr;
      s_St_Obstacle5 = Line_follower__St_Obstacle5;
      s = s_St_Obstacle5;
      r = r_St_Obstacle5;
      break;
    case Line_follower__St_Obstacle6:
      r_St_Obstacle6 = self->pnr;
      s_St_Obstacle6 = Line_follower__St_Obstacle6;
      s = s_St_Obstacle6;
      r = r_St_Obstacle6;
      break;
    case Line_follower__St_Junction3:
      v_49 = sen[3];
      v_50 = (v_49<500);
      v_47 = sen[1];
      v_48 = (v_47<500);
      v_51 = (v_48&&v_50);
      if (v_51) {
        r_St_Junction3 = true;
        s_St_Junction3 = Line_follower__St_ZNormal;
      } else {
        r_St_Junction3 = self->pnr;
        s_St_Junction3 = Line_follower__St_Junction3;
      };
      s = s_St_Junction3;
      r = r_St_Junction3;
      break;
    default:
      break;
  };
  ck_1 = s;
  switch (ck_1) {
    case Line_follower__St_ZNormal:
      time_St_ZNormal = 0;
      stateno_St_ZNormal = 1;
      v_163 = (2*_out->correction);
      v_164 = (base_speed+v_163);
      Line_follower__abs_step(v_164, &Line_follower__abs_out_st);
      v_165 = Line_follower__abs_out_st.b;
      v_162 = (base_speed+_out->correction);
      v_161 = (_out->correction>0);
      if (v_161) {
        v_166 = v_162;
      } else {
        v_166 = v_165;
      };
      v_159 = sen[4];
      v_160 = (v_159>600);
      if (v_160) {
        v_l_St_ZNormal = 50;
      } else {
        v_l_St_ZNormal = v_166;
      };
      v_157 = (base_speed-_out->correction);
      v_154 = (2*_out->correction);
      v_155 = (base_speed-v_154);
      Line_follower__abs_step(v_155, &Line_follower__abs_out_st);
      v_156 = Line_follower__abs_out_st.b;
      v_153 = (_out->correction>0);
      if (v_153) {
        v_158 = v_156;
      } else {
        v_158 = v_157;
      };
      v_151 = sen[4];
      v_152 = (v_151>600);
      if (v_152) {
        v_r_St_ZNormal = 50;
      } else {
        v_r_St_ZNormal = v_158;
      };
      v_146 = (2*_out->correction);
      v_147 = (base_speed+v_146);
      v_148 = (v_147<0);
      if (v_148) {
        v_149 = 2;
      } else {
        v_149 = 1;
      };
      v_143 = (2*_out->correction);
      v_144 = (base_speed-v_143);
      v_145 = (v_144<0);
      if (v_145) {
        v_150 = 3;
      } else {
        v_150 = v_149;
      };
      v_141 = sen[4];
      v_142 = (v_141>500);
      if (v_142) {
        dir_St_ZNormal = 1;
      } else {
        dir_St_ZNormal = v_150;
      };
      nr_St_ZNormal = false;
      ns_St_ZNormal = Line_follower__St_ZNormal;
      _out->v_l = v_l_St_ZNormal;
      _out->v_r = v_r_St_ZNormal;
      _out->dir = dir_St_ZNormal;
      _out->stateno = stateno_St_ZNormal;
      time = time_St_ZNormal;
      ns = ns_St_ZNormal;
      nr = nr_St_ZNormal;
      break;
    case Line_follower__St_Junction1:
      time_St_Junction1 = 0;
      stateno_St_Junction1 = 2;
      dir_St_Junction1 = 3;
      v_r_St_Junction1 = 40;
      v_l_St_Junction1 = 60;
      nr_St_Junction1 = false;
      ns_St_Junction1 = Line_follower__St_Junction1;
      _out->v_l = v_l_St_Junction1;
      _out->v_r = v_r_St_Junction1;
      _out->dir = dir_St_Junction1;
      _out->stateno = stateno_St_Junction1;
      time = time_St_Junction1;
      ns = ns_St_Junction1;
      nr = nr_St_Junction1;
      break;
    case Line_follower__St_Normal2:
      v_140 = (self->v_139-1);
      if (self->v_137) {
        v_138 = true;
      } else {
        v_138 = r;
      };
      if (v_138) {
        time_St_Normal2 = 100;
      } else {
        time_St_Normal2 = v_140;
      };
      stateno_St_Normal2 = 3;
      v_134 = (2*_out->correction);
      v_135 = (base_speed+v_134);
      Line_follower__abs_step(v_135, &Line_follower__abs_out_st);
      v_136 = Line_follower__abs_out_st.b;
      v_133 = (base_speed+_out->correction);
      v_132 = (_out->correction>0);
      if (v_132) {
        v_l_St_Normal2 = v_133;
      } else {
        v_l_St_Normal2 = v_136;
      };
      v_131 = (base_speed-_out->correction);
      v_128 = (2*_out->correction);
      v_129 = (base_speed-v_128);
      Line_follower__abs_step(v_129, &Line_follower__abs_out_st);
      v_130 = Line_follower__abs_out_st.b;
      v_127 = (_out->correction>0);
      if (v_127) {
        v_r_St_Normal2 = v_130;
      } else {
        v_r_St_Normal2 = v_131;
      };
      v_123 = (2*_out->correction);
      v_124 = (base_speed+v_123);
      v_125 = (v_124<0);
      if (v_125) {
        v_126 = 2;
      } else {
        v_126 = 1;
      };
      v_120 = (2*_out->correction);
      v_121 = (base_speed-v_120);
      v_122 = (v_121<0);
      if (v_122) {
        dir_St_Normal2 = 3;
      } else {
        dir_St_Normal2 = v_126;
      };
      v_117 = sen[3];
      v_118 = (v_117>500);
      v_114 = sen[2];
      v_115 = (v_114>375);
      v_111 = sen[1];
      v_112 = (v_111>500);
      _out->v_l = v_l_St_Normal2;
      _out->v_r = v_r_St_Normal2;
      _out->dir = dir_St_Normal2;
      _out->stateno = stateno_St_Normal2;
      time = time_St_Normal2;
      v_110 = (time<0);
      v_113 = (v_110&&v_112);
      v_116 = (v_113&&v_115);
      v_119 = (v_116&&v_118);
      if (v_119) {
        nr_St_Normal2 = true;
        ns_St_Normal2 = Line_follower__St_Junction2;
      } else {
        nr_St_Normal2 = false;
        ns_St_Normal2 = Line_follower__St_Normal2;
      };
      ns = ns_St_Normal2;
      nr = nr_St_Normal2;
      self->v_139 = time;
      self->v_137 = false;
      break;
    case Line_follower__St_Junction2:
      time_St_Junction2 = 0;
      stateno_St_Junction2 = 4;
      dir_St_Junction2 = 3;
      v_r_St_Junction2 = 40;
      v_l_St_Junction2 = 60;
      nr_St_Junction2 = false;
      ns_St_Junction2 = Line_follower__St_Junction2;
      _out->v_l = v_l_St_Junction2;
      _out->v_r = v_r_St_Junction2;
      _out->dir = dir_St_Junction2;
      _out->stateno = stateno_St_Junction2;
      time = time_St_Junction2;
      ns = ns_St_Junction2;
      nr = nr_St_Junction2;
      break;
    case Line_follower__St_Normal3:
      v_109 = (self->v_108-1);
      if (self->v_106) {
        v_107 = true;
      } else {
        v_107 = r;
      };
      if (v_107) {
        time_St_Normal3 = 100;
      } else {
        time_St_Normal3 = v_109;
      };
      stateno_St_Normal3 = 5;
      v_103 = (2*_out->correction);
      v_104 = (base_speed+v_103);
      Line_follower__abs_step(v_104, &Line_follower__abs_out_st);
      v_105 = Line_follower__abs_out_st.b;
      v_102 = (base_speed+_out->correction);
      v_101 = (_out->correction>0);
      if (v_101) {
        v_l_St_Normal3 = v_102;
      } else {
        v_l_St_Normal3 = v_105;
      };
      v_100 = (base_speed-_out->correction);
      v_97 = (2*_out->correction);
      v_98 = (base_speed-v_97);
      Line_follower__abs_step(v_98, &Line_follower__abs_out_st);
      v_99 = Line_follower__abs_out_st.b;
      v_96 = (_out->correction>0);
      if (v_96) {
        v_r_St_Normal3 = v_99;
      } else {
        v_r_St_Normal3 = v_100;
      };
      v_92 = (2*_out->correction);
      v_93 = (base_speed+v_92);
      v_94 = (v_93<0);
      if (v_94) {
        v_95 = 2;
      } else {
        v_95 = 1;
      };
      v_89 = (2*_out->correction);
      v_90 = (base_speed-v_89);
      v_91 = (v_90<0);
      if (v_91) {
        dir_St_Normal3 = 3;
      } else {
        dir_St_Normal3 = v_95;
      };
      if (ir1) {
        v_88 = true;
        v_87 = Line_follower__St_Obstacle1;
      } else {
        v_88 = false;
        v_87 = Line_follower__St_Normal3;
      };
      v_84 = sen[3];
      v_85 = (v_84>500);
      v_81 = sen[2];
      v_82 = (v_81>400);
      v_78 = sen[1];
      v_79 = (v_78>500);
      _out->v_l = v_l_St_Normal3;
      _out->v_r = v_r_St_Normal3;
      _out->dir = dir_St_Normal3;
      _out->stateno = stateno_St_Normal3;
      time = time_St_Normal3;
      v_77 = (time<0);
      v_80 = (v_77&&v_79);
      v_83 = (v_80&&v_82);
      v_86 = (v_83&&v_85);
      if (v_86) {
        nr_St_Normal3 = true;
        ns_St_Normal3 = Line_follower__St_Junction3;
      } else {
        nr_St_Normal3 = v_88;
        ns_St_Normal3 = v_87;
      };
      ns = ns_St_Normal3;
      nr = nr_St_Normal3;
      self->v_108 = time;
      self->v_106 = false;
      break;
    case Line_follower__St_Obstacle6:
      v_71 = sen[2];
      time_St_Obstacle6 = 0;
      stateno_St_Obstacle6 = 13;
      dir_St_Obstacle6 = 1;
      v_l_St_Obstacle6 = 50;
      v_r_St_Obstacle6 = 50;
      v_72 = (v_71>600);
      if (v_72) {
        nr_St_Obstacle6 = true;
        ns_St_Obstacle6 = Line_follower__St_Normal3;
      } else {
        nr_St_Obstacle6 = false;
        ns_St_Obstacle6 = Line_follower__St_Obstacle6;
      };
      _out->v_l = v_l_St_Obstacle6;
      _out->v_r = v_r_St_Obstacle6;
      _out->dir = dir_St_Obstacle6;
      _out->stateno = stateno_St_Obstacle6;
      time = time_St_Obstacle6;
      ns = ns_St_Obstacle6;
      nr = nr_St_Obstacle6;
      break;
    case Line_follower__St_Obstacle1:
      time_St_Obstacle1 = 0;
      stateno_St_Obstacle1 = 7;
      dir_St_Obstacle1 = 3;
      v_l_St_Obstacle1 = 50;
      v_r_St_Obstacle1 = 25;
      v_75 = !(ir3);
      v_76 = (ir2&&v_75);
      if (v_76) {
        nr_St_Obstacle1 = true;
        ns_St_Obstacle1 = Line_follower__St_Obstacle2;
      } else {
        nr_St_Obstacle1 = false;
        ns_St_Obstacle1 = Line_follower__St_Obstacle1;
      };
      _out->v_l = v_l_St_Obstacle1;
      _out->v_r = v_r_St_Obstacle1;
      _out->dir = dir_St_Obstacle1;
      _out->stateno = stateno_St_Obstacle1;
      time = time_St_Obstacle1;
      ns = ns_St_Obstacle1;
      nr = nr_St_Obstacle1;
      break;
    case Line_follower__St_Obstacle2:
      stateno_St_Obstacle2 = 8;
      time_St_Obstacle2 = 0;
      dir_St_Obstacle2 = 1;
      v_l_St_Obstacle2 = 50;
      v_r_St_Obstacle2 = 50;
      v_74 = !(ir2);
      if (v_74) {
        nr_St_Obstacle2 = true;
        ns_St_Obstacle2 = Line_follower__St_Obstacle3;
      } else {
        nr_St_Obstacle2 = false;
        ns_St_Obstacle2 = Line_follower__St_Obstacle2;
      };
      _out->v_l = v_l_St_Obstacle2;
      _out->v_r = v_r_St_Obstacle2;
      _out->dir = dir_St_Obstacle2;
      _out->stateno = stateno_St_Obstacle2;
      time = time_St_Obstacle2;
      ns = ns_St_Obstacle2;
      nr = nr_St_Obstacle2;
      break;
    case Line_follower__St_Obstacle3:
      stateno_St_Obstacle3 = 9;
      time_St_Obstacle3 = 0;
      dir_St_Obstacle3 = 1;
      v_l_St_Obstacle3 = 20;
      v_r_St_Obstacle3 = 50;
      if (ir3) {
        nr_St_Obstacle3 = true;
        ns_St_Obstacle3 = Line_follower__St_Right;
      } else {
        nr_St_Obstacle3 = false;
        ns_St_Obstacle3 = Line_follower__St_Obstacle3;
      };
      _out->v_l = v_l_St_Obstacle3;
      _out->v_r = v_r_St_Obstacle3;
      _out->dir = dir_St_Obstacle3;
      _out->stateno = stateno_St_Obstacle3;
      time = time_St_Obstacle3;
      ns = ns_St_Obstacle3;
      nr = nr_St_Obstacle3;
      break;
    case Line_follower__St_Right:
      stateno_St_Right = 10;
      time_St_Right = 0;
      dir_St_Right = 3;
      v_r_St_Right = 50;
      v_l_St_Right = 50;
      if (ir2) {
        nr_St_Right = true;
        ns_St_Right = Line_follower__St_Obstacle4;
      } else {
        nr_St_Right = false;
        ns_St_Right = Line_follower__St_Right;
      };
      _out->v_l = v_l_St_Right;
      _out->v_r = v_r_St_Right;
      _out->dir = dir_St_Right;
      _out->stateno = stateno_St_Right;
      time = time_St_Right;
      ns = ns_St_Right;
      nr = nr_St_Right;
      break;
    case Line_follower__St_Obstacle4:
      time_St_Obstacle4 = 0;
      stateno_St_Obstacle4 = 11;
      dir_St_Obstacle4 = 1;
      v_l_St_Obstacle4 = 50;
      v_r_St_Obstacle4 = 50;
      v_73 = !(ir2);
      if (v_73) {
        nr_St_Obstacle4 = true;
        ns_St_Obstacle4 = Line_follower__St_Obstacle5;
      } else {
        nr_St_Obstacle4 = false;
        ns_St_Obstacle4 = Line_follower__St_Obstacle4;
      };
      _out->v_l = v_l_St_Obstacle4;
      _out->v_r = v_r_St_Obstacle4;
      _out->dir = dir_St_Obstacle4;
      _out->stateno = stateno_St_Obstacle4;
      time = time_St_Obstacle4;
      ns = ns_St_Obstacle4;
      nr = nr_St_Obstacle4;
      break;
    case Line_follower__St_Obstacle5:
      time_St_Obstacle5 = 0;
      stateno_St_Obstacle5 = 12;
      dir_St_Obstacle5 = 1;
      v_l_St_Obstacle5 = 20;
      v_r_St_Obstacle5 = 50;
      if (ir2) {
        nr_St_Obstacle5 = true;
        ns_St_Obstacle5 = Line_follower__St_Obstacle6;
      } else {
        nr_St_Obstacle5 = false;
        ns_St_Obstacle5 = Line_follower__St_Obstacle5;
      };
      _out->v_l = v_l_St_Obstacle5;
      _out->v_r = v_r_St_Obstacle5;
      _out->dir = dir_St_Obstacle5;
      _out->stateno = stateno_St_Obstacle5;
      time = time_St_Obstacle5;
      ns = ns_St_Obstacle5;
      nr = nr_St_Obstacle5;
      break;
    case Line_follower__St_Junction3:
      time_St_Junction3 = 0;
      stateno_St_Junction3 = 6;
      dir_St_Junction3 = 2;
      v_r_St_Junction3 = 40;
      v_l_St_Junction3 = 60;
      nr_St_Junction3 = false;
      ns_St_Junction3 = Line_follower__St_Junction3;
      _out->v_l = v_l_St_Junction3;
      _out->v_r = v_r_St_Junction3;
      _out->dir = dir_St_Junction3;
      _out->stateno = stateno_St_Junction3;
      time = time_St_Junction3;
      ns = ns_St_Junction3;
      nr = nr_St_Junction3;
      break;
    default:
      break;
  };
  self->error_1 = error;
  self->pnr = nr;
  self->ck = ns;
  self->v_38 = longegral;
  self->v_37 = false;;
}

void Line_follower__less_step(long a, long out, Line_follower__less_out* _out) {
  
  long v;
  v = (a<out);
  if (v) {
    _out->b = a;
  } else {
    _out->b = out;
  };;
}

void Line_follower__more_step(long a, long out, Line_follower__more_out* _out) {
  
  long v;
  v = (a>out);
  if (v) {
    _out->b = a;
  } else {
    _out->b = out;
  };;
}

void Line_follower__caliberate_step(long v, long min, long max,
                                    Line_follower__caliberate_out* _out) {
  
  long v_169;
  long v_168;
  long v_167;
  v_169 = (max-min);
  v_167 = (v-min);
  v_168 = (1000*v_167);
  _out->cal_val = (v_168/v_169);;
}

void Line_follower__main_reset(Line_follower__main_mem* self) {
  Line_follower__line_follower_reset(&self->line_follower);
  self->v_176 = true;
}

void Line_follower__main_step(long sen0, long sen1, long sen2, long sen3,
                              long sen4, long ir0, long ir1, long ir2, long ir3,
                              Line_follower__main_out* _out,
                              Line_follower__main_mem* self) {
  Line_follower__line_follower_out Line_follower__line_follower_out_st;
  
  long v_186[5];
  long v_185[5];
  long v_184;
  long v_183;
  long v_182;
  long v_181;
  long v_180;
  long v_179;
  long v_177;
  long v_175;
  long v_174;
  long v_173;
  long v_172;
  long v_171;
  long v_170;
  long v;
  long out[5];
  long line_switch;
  _out->s4 = sen4;
  _out->s3 = sen3;
  _out->s2 = sen2;
  _out->s1 = sen1;
  _out->s0 = sen0;
  v_184 = (1023-sen4);
  v_183 = (1023-sen3);
  v_182 = (1023-sen2);
  v_181 = (1023-sen1);
  v_180 = (1023-sen0);
  v_175 = (2*sen2);
  v_173 = (sen4*1);
  v_170 = (sen1*1);
  v = (sen0*1);
  v_171 = (v+v_170);
  v_172 = (v_171+sen3);
  v_174 = (v_172+v_173);
  _out->err = (v_174-v_175);
  v_177 = (_out->err>1000);
  v_179 = (v_177||self->v_178);
  if (self->v_176) {
    line_switch = false;
  } else {
    line_switch = v_179;
  };
  _out->ls = line_switch;
  v_186[0] = sen0;
  v_186[1] = sen1;
  v_186[2] = sen2;
  v_186[3] = sen3;
  v_186[4] = sen4;
  v_185[0] = v_180;
  v_185[1] = v_181;
  v_185[2] = v_182;
  v_185[3] = v_183;
  v_185[4] = v_184;
  if (line_switch) {
    {
      long _1;
      for (_1 = 0; _1 < 5; ++_1) {
        out[_1] = v_185[_1];
      }
    };
  } else {
    {
      long _2;
      for (_2 = 0; _2 < 5; ++_2) {
        out[_2] = v_186[_2];
      }
    };
  };
  Line_follower__line_follower_step(out, line_switch, ir0, ir1, ir2, ir3,
                                    &Line_follower__line_follower_out_st,
                                    &self->line_follower);
  _out->v_l = Line_follower__line_follower_out_st.v_l;
  _out->v_r = Line_follower__line_follower_out_st.v_r;
  _out->dir = Line_follower__line_follower_out_st.dir;
  _out->correction = Line_follower__line_follower_out_st.correction;
  _out->stateno = Line_follower__line_follower_out_st.stateno;
  self->v_178 = line_switch;
  self->v_176 = false;;
}

