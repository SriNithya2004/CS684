/* --- Generated the 31/3/2025 at 5:9 --- */
/* --- heptagon compiler, version 1.05.00 (compiled wed. mar. 19 17:12:18 CET 2025) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts line_follower.ept --- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "line_follower_types.h"

Line_follower__st Line_follower__st_of_string(char* s) {
  if ((strcmp(s, "St_ZNormal")==0)) {
    return Line_follower__St_ZNormal;
  };
  if ((strcmp(s, "St_Right")==0)) {
    return Line_follower__St_Right;
  };
  if ((strcmp(s, "St_Obstacle6")==0)) {
    return Line_follower__St_Obstacle6;
  };
  if ((strcmp(s, "St_Obstacle5")==0)) {
    return Line_follower__St_Obstacle5;
  };
  if ((strcmp(s, "St_Obstacle4")==0)) {
    return Line_follower__St_Obstacle4;
  };
  if ((strcmp(s, "St_Obstacle3")==0)) {
    return Line_follower__St_Obstacle3;
  };
  if ((strcmp(s, "St_Obstacle2")==0)) {
    return Line_follower__St_Obstacle2;
  };
  if ((strcmp(s, "St_Obstacle1")==0)) {
    return Line_follower__St_Obstacle1;
  };
  if ((strcmp(s, "St_Normal3")==0)) {
    return Line_follower__St_Normal3;
  };
  if ((strcmp(s, "St_Normal2")==0)) {
    return Line_follower__St_Normal2;
  };
  if ((strcmp(s, "St_Junction3")==0)) {
    return Line_follower__St_Junction3;
  };
  if ((strcmp(s, "St_Junction2")==0)) {
    return Line_follower__St_Junction2;
  };
  if ((strcmp(s, "St_Junction1")==0)) {
    return Line_follower__St_Junction1;
  };
}

char* string_of_Line_follower__st(Line_follower__st x, char* buf) {
  switch (x) {
    case Line_follower__St_ZNormal:
      strcpy(buf, "St_ZNormal");
      break;
    case Line_follower__St_Right:
      strcpy(buf, "St_Right");
      break;
    case Line_follower__St_Obstacle6:
      strcpy(buf, "St_Obstacle6");
      break;
    case Line_follower__St_Obstacle5:
      strcpy(buf, "St_Obstacle5");
      break;
    case Line_follower__St_Obstacle4:
      strcpy(buf, "St_Obstacle4");
      break;
    case Line_follower__St_Obstacle3:
      strcpy(buf, "St_Obstacle3");
      break;
    case Line_follower__St_Obstacle2:
      strcpy(buf, "St_Obstacle2");
      break;
    case Line_follower__St_Obstacle1:
      strcpy(buf, "St_Obstacle1");
      break;
    case Line_follower__St_Normal3:
      strcpy(buf, "St_Normal3");
      break;
    case Line_follower__St_Normal2:
      strcpy(buf, "St_Normal2");
      break;
    case Line_follower__St_Junction3:
      strcpy(buf, "St_Junction3");
      break;
    case Line_follower__St_Junction2:
      strcpy(buf, "St_Junction2");
      break;
    case Line_follower__St_Junction1:
      strcpy(buf, "St_Junction1");
      break;
    default:
      break;
  };
  return buf;
}

