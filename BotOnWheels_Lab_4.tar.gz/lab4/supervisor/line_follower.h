/* --- Generated the 31/3/2025 at 5:9 --- */
/* --- heptagon compiler, version 1.05.00 (compiled wed. mar. 19 17:12:18 CET 2025) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts line_follower.ept --- */

#ifndef LINE_FOLLOWER_H
#define LINE_FOLLOWER_H

#include "line_follower_types.h"
typedef struct Line_follower__black_check_out {
  long out;
} Line_follower__black_check_out;

void Line_follower__black_check_step(long sen0, long sen1, long sen2, long sen3,
                                     long sen4,
                                     Line_follower__black_check_out* _out);

typedef struct Line_follower__abs_out {
  long b;
} Line_follower__abs_out;

void Line_follower__abs_step(long a, Line_follower__abs_out* _out);

typedef struct Line_follower__line_follower_mem {
  Line_follower__st ck;
  long v_108;
  long v_106;
  long v_139;
  long v_137;
  long v_38;
  long v_37;
  long pnr;
  long error_1;
} Line_follower__line_follower_mem;

typedef struct Line_follower__line_follower_out {
  long v_l;
  long v_r;
  long dir;
  long correction;
  long stateno;
} Line_follower__line_follower_out;

void Line_follower__line_follower_reset(Line_follower__line_follower_mem* self);

void Line_follower__line_follower_step(long sen[5], long line_switch, long ir0,
                                       long ir1, long ir2, long ir3,
                                       Line_follower__line_follower_out* _out,
                                       Line_follower__line_follower_mem* self);

typedef struct Line_follower__less_out {
  long b;
} Line_follower__less_out;

void Line_follower__less_step(long a, long out, Line_follower__less_out* _out);

typedef struct Line_follower__more_out {
  long b;
} Line_follower__more_out;

void Line_follower__more_step(long a, long out, Line_follower__more_out* _out);

typedef struct Line_follower__caliberate_out {
  long cal_val;
} Line_follower__caliberate_out;

void Line_follower__caliberate_step(long v, long min, long max,
                                    Line_follower__caliberate_out* _out);

typedef struct Line_follower__main_mem {
  long v_178;
  long v_176;
  Line_follower__line_follower_mem line_follower;
} Line_follower__main_mem;

typedef struct Line_follower__main_out {
  long v_l;
  long v_r;
  long dir;
  long correction;
  long err;
  long stateno;
  long s0;
  long s1;
  long s2;
  long s3;
  long s4;
  long ls;
} Line_follower__main_out;

void Line_follower__main_reset(Line_follower__main_mem* self);

void Line_follower__main_step(long sen0, long sen1, long sen2, long sen3,
                              long sen4, long ir0, long ir1, long ir2, long ir3,
                              Line_follower__main_out* _out,
                              Line_follower__main_mem* self);

#endif // LINE_FOLLOWER_H
