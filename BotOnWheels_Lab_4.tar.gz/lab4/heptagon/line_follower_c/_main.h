/* --- Generated the 31/3/2025 at 5:9 --- */
/* --- heptagon compiler, version 1.05.00 (compiled wed. mar. 19 17:12:18 CET 2025) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts line_follower.ept --- */

#ifndef _MAIN_H
#define _MAIN_H

#include "line_follower.h"
#endif // _MAIN_H
