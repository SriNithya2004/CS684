/* --- Generated the 31/3/2025 at 5:9 --- */
/* --- heptagon compiler, version 1.05.00 (compiled wed. mar. 19 17:12:18 CET 2025) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts line_follower.ept --- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "line_follower.h"

void Line_follower__black_check_step(int sen0, int sen1, int sen2, int sen3,
                                     int sen4,
                                     Line_follower__black_check_out* _out) {
  
  int v_23;
  int v_22;
  int v_21;
  int v_20;
  int v_19;
  int v_18;
  int v_17;
  int v_16;
  int v_15;
  int v_14;
  int v_13;
  int v_12;
  int v_11;
  int v_10;
  int v_9;
  int v_8;
  int v_7;
  int v_6;
  int v_5;
  int v_4;
  int v_3;
  int v_2;
  int v_1;
  int v;
  int avg;
  int param;
  param = 100;
  v = (sen0+sen1);
  v_1 = (v+sen2);
  v_2 = (v_1+sen3);
  v_3 = (v_2+sen4);
  avg = (v_3/5);
  v_20 = (sen4-avg);
  v_19 = (sen4-avg);
  v_21 = (v_19*v_20);
  v_16 = (sen3-avg);
  v_15 = (sen3-avg);
  v_17 = (v_15*v_16);
  v_12 = (sen2-avg);
  v_11 = (sen2-avg);
  v_13 = (v_11*v_12);
  v_8 = (sen1-avg);
  v_7 = (sen1-avg);
  v_9 = (v_7*v_8);
  v_5 = (sen0-avg);
  v_4 = (sen0-avg);
  v_6 = (v_4*v_5);
  v_10 = (v_6+v_9);
  v_14 = (v_10+v_13);
  v_18 = (v_14+v_17);
  v_22 = (v_18+v_21);
  v_23 = (v_22<100);
  if (v_23) {
    _out->out = true;
  } else {
    _out->out = false;
  };;
}

void Line_follower__abs_step(int a, Line_follower__abs_out* _out) {
  
  int v_24;
  int v;
  v_24 = -(a);
  v = (a<0);
  if (v) {
    _out->b = v_24;
  } else {
    _out->b = a;
  };;
}

void Line_follower__line_follower_reset(Line_follower__line_follower_mem* self) {
  self->v_137 = true;
  self->v_106 = true;
  self->error_1 = 0;
  self->pnr = false;
  self->ck = Line_follower__St_ZNormal;
  self->v_37 = true;
}

void Line_follower__line_follower_step(int sen[5], int line_switch, int ir0,
                                       int ir1, int ir2, int ir3,
                                       Line_follower__line_follower_out* _out,
                                       Line_follower__line_follower_mem* self) {
  Line_follower__abs_out Line_follower__abs_out_st;
  
  int v_51;
  int v_50;
  int v_49;
  int v_48;
  int v_47;
  int v_56;
  int v_55;
  int v_54;
  int v_53;
  int v_52;
  int v_61;
  int v_60;
  int v_59;
  int v_58;
  int v_57;
  int v_70;
  int v_69;
  int v_68;
  int v_67;
  int v_66;
  int v_65;
  int v_64;
  int v_63;
  int v_62;
  int r_St_Junction3;
  Line_follower__st s_St_Junction3;
  int r_St_Obstacle6;
  Line_follower__st s_St_Obstacle6;
  int r_St_Obstacle5;
  Line_follower__st s_St_Obstacle5;
  int r_St_Obstacle4;
  Line_follower__st s_St_Obstacle4;
  int r_St_Right;
  Line_follower__st s_St_Right;
  int r_St_Obstacle3;
  Line_follower__st s_St_Obstacle3;
  int r_St_Obstacle2;
  Line_follower__st s_St_Obstacle2;
  int r_St_Obstacle1;
  Line_follower__st s_St_Obstacle1;
  int r_St_Normal3;
  Line_follower__st s_St_Normal3;
  int r_St_Junction2;
  Line_follower__st s_St_Junction2;
  int r_St_Normal2;
  Line_follower__st s_St_Normal2;
  int r_St_Junction1;
  Line_follower__st s_St_Junction1;
  int r_St_ZNormal;
  Line_follower__st s_St_ZNormal;
  int v_72;
  int v_71;
  int v_73;
  int v_74;
  int v_76;
  int v_75;
  int v_109;
  int v_107;
  int v_105;
  int v_104;
  int v_103;
  int v_102;
  int v_101;
  int v_100;
  int v_99;
  int v_98;
  int v_97;
  int v_96;
  int v_95;
  int v_94;
  int v_93;
  int v_92;
  int v_91;
  int v_90;
  int v_89;
  int v_88;
  Line_follower__st v_87;
  int v_86;
  int v_85;
  int v_84;
  int v_83;
  int v_82;
  int v_81;
  int v_80;
  int v_79;
  int v_78;
  int v_77;
  int v_140;
  int v_138;
  int v_136;
  int v_135;
  int v_134;
  int v_133;
  int v_132;
  int v_131;
  int v_130;
  int v_129;
  int v_128;
  int v_127;
  int v_126;
  int v_125;
  int v_124;
  int v_123;
  int v_122;
  int v_121;
  int v_120;
  int v_119;
  int v_118;
  int v_117;
  int v_116;
  int v_115;
  int v_114;
  int v_113;
  int v_112;
  int v_111;
  int v_110;
  int v_166;
  int v_165;
  int v_164;
  int v_163;
  int v_162;
  int v_161;
  int v_160;
  int v_159;
  int v_158;
  int v_157;
  int v_156;
  int v_155;
  int v_154;
  int v_153;
  int v_152;
  int v_151;
  int v_150;
  int v_149;
  int v_148;
  int v_147;
  int v_146;
  int v_145;
  int v_144;
  int v_143;
  int v_142;
  int v_141;
  int nr_St_Junction3;
  Line_follower__st ns_St_Junction3;
  int time_St_Junction3;
  int stateno_St_Junction3;
  int dir_St_Junction3;
  int v_r_St_Junction3;
  int v_l_St_Junction3;
  int nr_St_Obstacle6;
  Line_follower__st ns_St_Obstacle6;
  int time_St_Obstacle6;
  int stateno_St_Obstacle6;
  int dir_St_Obstacle6;
  int v_r_St_Obstacle6;
  int v_l_St_Obstacle6;
  int nr_St_Obstacle5;
  Line_follower__st ns_St_Obstacle5;
  int time_St_Obstacle5;
  int stateno_St_Obstacle5;
  int dir_St_Obstacle5;
  int v_r_St_Obstacle5;
  int v_l_St_Obstacle5;
  int nr_St_Obstacle4;
  Line_follower__st ns_St_Obstacle4;
  int time_St_Obstacle4;
  int stateno_St_Obstacle4;
  int dir_St_Obstacle4;
  int v_r_St_Obstacle4;
  int v_l_St_Obstacle4;
  int nr_St_Right;
  Line_follower__st ns_St_Right;
  int time_St_Right;
  int stateno_St_Right;
  int dir_St_Right;
  int v_r_St_Right;
  int v_l_St_Right;
  int nr_St_Obstacle3;
  Line_follower__st ns_St_Obstacle3;
  int time_St_Obstacle3;
  int stateno_St_Obstacle3;
  int dir_St_Obstacle3;
  int v_r_St_Obstacle3;
  int v_l_St_Obstacle3;
  int nr_St_Obstacle2;
  Line_follower__st ns_St_Obstacle2;
  int time_St_Obstacle2;
  int stateno_St_Obstacle2;
  int dir_St_Obstacle2;
  int v_r_St_Obstacle2;
  int v_l_St_Obstacle2;
  int nr_St_Obstacle1;
  Line_follower__st ns_St_Obstacle1;
  int time_St_Obstacle1;
  int stateno_St_Obstacle1;
  int dir_St_Obstacle1;
  int v_r_St_Obstacle1;
  int v_l_St_Obstacle1;
  int nr_St_Normal3;
  Line_follower__st ns_St_Normal3;
  int time_St_Normal3;
  int stateno_St_Normal3;
  int dir_St_Normal3;
  int v_r_St_Normal3;
  int v_l_St_Normal3;
  int nr_St_Junction2;
  Line_follower__st ns_St_Junction2;
  int time_St_Junction2;
  int stateno_St_Junction2;
  int dir_St_Junction2;
  int v_r_St_Junction2;
  int v_l_St_Junction2;
  int nr_St_Normal2;
  Line_follower__st ns_St_Normal2;
  int time_St_Normal2;
  int stateno_St_Normal2;
  int dir_St_Normal2;
  int v_r_St_Normal2;
  int v_l_St_Normal2;
  int nr_St_Junction1;
  Line_follower__st ns_St_Junction1;
  int time_St_Junction1;
  int stateno_St_Junction1;
  int dir_St_Junction1;
  int v_r_St_Junction1;
  int v_l_St_Junction1;
  int nr_St_ZNormal;
  Line_follower__st ns_St_ZNormal;
  int time_St_ZNormal;
  int stateno_St_ZNormal;
  int dir_St_ZNormal;
  int v_r_St_ZNormal;
  int v_l_St_ZNormal;
  Line_follower__st ck_1;
  int v_46;
  int v_45;
  int v_44;
  int v_43;
  int v_42;
  int v_41;
  int v_40;
  int v_39;
  int v_36;
  int v_35;
  int v_34;
  int v_33;
  int v_32;
  int v_31;
  int v_30;
  int v_29;
  int v_28;
  int v_27;
  int v_26;
  int v_25;
  int v;
  Line_follower__st s;
  Line_follower__st ns;
  int r;
  int nr;
  int error;
  int integral;
  int derivative;
  int kp;
  int ki;
  int kd;
  int base_speed;
  int time;
  v_39 = (self->v_38*9);
  v_40 = (v_39/10);
  v_35 = sen[4];
  v_36 = (v_35*2);
  v_32 = sen[3];
  v_33 = (v_32*1);
  v_29 = sen[2];
  v_30 = (v_29*0);
  v_26 = sen[1];
  v_27 = (v_26*-1);
  v = sen[0];
  v_25 = (v*-2);
  v_28 = (v_25+v_27);
  v_31 = (v_28+v_30);
  v_34 = (v_31+v_33);
  error = (v_34+v_36);
  derivative = (error-self->error_1);
  v_41 = (v_40+error);
  if (self->v_37) {
    integral = 0;
  } else {
    integral = v_41;
  };
  base_speed = 50;
  kd = 20;
  v_45 = (kd*derivative);
  ki = 0;
  v_43 = (ki*integral);
  kp = 65;
  v_42 = (kp*error);
  v_44 = (v_42+v_43);
  v_46 = (v_44+v_45);
  _out->correction = (v_46/1000);
  switch (self->ck) {
    case Line_follower__St_ZNormal:
      v_68 = sen[3];
      v_69 = (v_68>500);
      v_65 = sen[2];
      v_66 = (v_65>400);
      v_62 = sen[1];
      v_63 = (v_62>500);
      v_64 = (line_switch&&v_63);
      v_67 = (v_64&&v_66);
      v_70 = (v_67&&v_69);
      if (v_70) {
        r_St_ZNormal = true;
        s_St_ZNormal = Line_follower__St_Junction1;
      } else {
        r_St_ZNormal = self->pnr;
        s_St_ZNormal = Line_follower__St_ZNormal;
      };
      s = s_St_ZNormal;
      r = r_St_ZNormal;
      break;
    case Line_follower__St_Junction1:
      v_59 = sen[3];
      v_60 = (v_59<500);
      v_57 = sen[1];
      v_58 = (v_57<500);
      v_61 = (v_58&&v_60);
      if (v_61) {
        r_St_Junction1 = true;
        s_St_Junction1 = Line_follower__St_Normal2;
      } else {
        r_St_Junction1 = self->pnr;
        s_St_Junction1 = Line_follower__St_Junction1;
      };
      s = s_St_Junction1;
      r = r_St_Junction1;
      break;
    case Line_follower__St_Normal2:
      r_St_Normal2 = self->pnr;
      s_St_Normal2 = Line_follower__St_Normal2;
      s = s_St_Normal2;
      r = r_St_Normal2;
      break;
    case Line_follower__St_Junction2:
      v_54 = sen[3];
      v_55 = (v_54<500);
      v_52 = sen[1];
      v_53 = (v_52<500);
      v_56 = (v_53&&v_55);
      if (v_56) {
        r_St_Junction2 = true;
        s_St_Junction2 = Line_follower__St_Normal3;
      } else {
        r_St_Junction2 = self->pnr;
        s_St_Junction2 = Line_follower__St_Junction2;
      };
      s = s_St_Junction2;
      r = r_St_Junction2;
      break;
    case Line_follower__St_Normal3:
      r_St_Normal3 = self->pnr;
      s_St_Normal3 = Line_follower__St_Normal3;
      s = s_St_Normal3;
      r = r_St_Normal3;
      break;
    case Line_follower__St_Obstacle1:
      r_St_Obstacle1 = self->pnr;
      s_St_Obstacle1 = Line_follower__St_Obstacle1;
      s = s_St_Obstacle1;
      r = r_St_Obstacle1;
      break;
    case Line_follower__St_Obstacle2:
      r_St_Obstacle2 = self->pnr;
      s_St_Obstacle2 = Line_follower__St_Obstacle2;
      s = s_St_Obstacle2;
      r = r_St_Obstacle2;
      break;
    case Line_follower__St_Obstacle3:
      r_St_Obstacle3 = self->pnr;
      s_St_Obstacle3 = Line_follower__St_Obstacle3;
      s = s_St_Obstacle3;
      r = r_St_Obstacle3;
      break;
    case Line_follower__St_Right:
      r_St_Right = self->pnr;
      s_St_Right = Line_follower__St_Right;
      s = s_St_Right;
      r = r_St_Right;
      break;
    case Line_follower__St_Obstacle4:
      r_St_Obstacle4 = self->pnr;
      s_St_Obstacle4 = Line_follower__St_Obstacle4;
      s = s_St_Obstacle4;
      r = r_St_Obstacle4;
      break;
    case Line_follower__St_Obstacle5:
      r_St_Obstacle5 = self->pnr;
      s_St_Obstacle5 = Line_follower__St_Obstacle5;
      s = s_St_Obstacle5;
      r = r_St_Obstacle5;
      break;
    case Line_follower__St_Obstacle6:
      r_St_Obstacle6 = self->pnr;
      s_St_Obstacle6 = Line_follower__St_Obstacle6;
      s = s_St_Obstacle6;
      r = r_St_Obstacle6;
      break;
    case Line_follower__St_Junction3:
      v_49 = sen[3];
      v_50 = (v_49<500);
      v_47 = sen[1];
      v_48 = (v_47<500);
      v_51 = (v_48&&v_50);
      if (v_51) {
        r_St_Junction3 = true;
        s_St_Junction3 = Line_follower__St_ZNormal;
      } else {
        r_St_Junction3 = self->pnr;
        s_St_Junction3 = Line_follower__St_Junction3;
      };
      s = s_St_Junction3;
      r = r_St_Junction3;
      break;
    default:
      break;
  };
  ck_1 = s;
  switch (ck_1) {
    case Line_follower__St_ZNormal:
      time_St_ZNormal = 0;
      stateno_St_ZNormal = 1;
      v_163 = (2*_out->correction);
      v_164 = (base_speed+v_163);
      Line_follower__abs_step(v_164, &Line_follower__abs_out_st);
      v_165 = Line_follower__abs_out_st.b;
      v_162 = (base_speed+_out->correction);
      v_161 = (_out->correction>0);
      if (v_161) {
        v_166 = v_162;
      } else {
        v_166 = v_165;
      };
      v_159 = sen[4];
      v_160 = (v_159>600);
      if (v_160) {
        v_l_St_ZNormal = 50;
      } else {
        v_l_St_ZNormal = v_166;
      };
      v_157 = (base_speed-_out->correction);
      v_154 = (2*_out->correction);
      v_155 = (base_speed-v_154);
      Line_follower__abs_step(v_155, &Line_follower__abs_out_st);
      v_156 = Line_follower__abs_out_st.b;
      v_153 = (_out->correction>0);
      if (v_153) {
        v_158 = v_156;
      } else {
        v_158 = v_157;
      };
      v_151 = sen[4];
      v_152 = (v_151>600);
      if (v_152) {
        v_r_St_ZNormal = 50;
      } else {
        v_r_St_ZNormal = v_158;
      };
      v_146 = (2*_out->correction);
      v_147 = (base_speed+v_146);
      v_148 = (v_147<0);
      if (v_148) {
        v_149 = 2;
      } else {
        v_149 = 1;
      };
      v_143 = (2*_out->correction);
      v_144 = (base_speed-v_143);
      v_145 = (v_144<0);
      if (v_145) {
        v_150 = 3;
      } else {
        v_150 = v_149;
      };
      v_141 = sen[4];
      v_142 = (v_141>500);
      if (v_142) {
        dir_St_ZNormal = 1;
      } else {
        dir_St_ZNormal = v_150;
      };
      nr_St_ZNormal = false;
      ns_St_ZNormal = Line_follower__St_ZNormal;
      _out->v_l = v_l_St_ZNormal;
      _out->v_r = v_r_St_ZNormal;
      _out->dir = dir_St_ZNormal;
      _out->stateno = stateno_St_ZNormal;
      time = time_St_ZNormal;
      ns = ns_St_ZNormal;
      nr = nr_St_ZNormal;
      break;
    case Line_follower__St_Junction1:
      time_St_Junction1 = 0;
      stateno_St_Junction1 = 2;
      dir_St_Junction1 = 3;
      v_r_St_Junction1 = 40;
      v_l_St_Junction1 = 60;
      nr_St_Junction1 = false;
      ns_St_Junction1 = Line_follower__St_Junction1;
      _out->v_l = v_l_St_Junction1;
      _out->v_r = v_r_St_Junction1;
      _out->dir = dir_St_Junction1;
      _out->stateno = stateno_St_Junction1;
      time = time_St_Junction1;
      ns = ns_St_Junction1;
      nr = nr_St_Junction1;
      break;
    case Line_follower__St_Normal2:
      v_140 = (self->v_139-1);
      if (self->v_137) {
        v_138 = true;
      } else {
        v_138 = r;
      };
      if (v_138) {
        time_St_Normal2 = 100;
      } else {
        time_St_Normal2 = v_140;
      };
      stateno_St_Normal2 = 3;
      v_134 = (2*_out->correction);
      v_135 = (base_speed+v_134);
      Line_follower__abs_step(v_135, &Line_follower__abs_out_st);
      v_136 = Line_follower__abs_out_st.b;
      v_133 = (base_speed+_out->correction);
      v_132 = (_out->correction>0);
      if (v_132) {
        v_l_St_Normal2 = v_133;
      } else {
        v_l_St_Normal2 = v_136;
      };
      v_131 = (base_speed-_out->correction);
      v_128 = (2*_out->correction);
      v_129 = (base_speed-v_128);
      Line_follower__abs_step(v_129, &Line_follower__abs_out_st);
      v_130 = Line_follower__abs_out_st.b;
      v_127 = (_out->correction>0);
      if (v_127) {
        v_r_St_Normal2 = v_130;
      } else {
        v_r_St_Normal2 = v_131;
      };
      v_123 = (2*_out->correction);
      v_124 = (base_speed+v_123);
      v_125 = (v_124<0);
      if (v_125) {
        v_126 = 2;
      } else {
        v_126 = 1;
      };
      v_120 = (2*_out->correction);
      v_121 = (base_speed-v_120);
      v_122 = (v_121<0);
      if (v_122) {
        dir_St_Normal2 = 3;
      } else {
        dir_St_Normal2 = v_126;
      };
      v_117 = sen[3];
      v_118 = (v_117>500);
      v_114 = sen[2];
      v_115 = (v_114>375);
      v_111 = sen[1];
      v_112 = (v_111>500);
      _out->v_l = v_l_St_Normal2;
      _out->v_r = v_r_St_Normal2;
      _out->dir = dir_St_Normal2;
      _out->stateno = stateno_St_Normal2;
      time = time_St_Normal2;
      v_110 = (time<0);
      v_113 = (v_110&&v_112);
      v_116 = (v_113&&v_115);
      v_119 = (v_116&&v_118);
      if (v_119) {
        nr_St_Normal2 = true;
        ns_St_Normal2 = Line_follower__St_Junction2;
      } else {
        nr_St_Normal2 = false;
        ns_St_Normal2 = Line_follower__St_Normal2;
      };
      ns = ns_St_Normal2;
      nr = nr_St_Normal2;
      self->v_139 = time;
      self->v_137 = false;
      break;
    case Line_follower__St_Junction2:
      time_St_Junction2 = 0;
      stateno_St_Junction2 = 4;
      dir_St_Junction2 = 3;
      v_r_St_Junction2 = 40;
      v_l_St_Junction2 = 60;
      nr_St_Junction2 = false;
      ns_St_Junction2 = Line_follower__St_Junction2;
      _out->v_l = v_l_St_Junction2;
      _out->v_r = v_r_St_Junction2;
      _out->dir = dir_St_Junction2;
      _out->stateno = stateno_St_Junction2;
      time = time_St_Junction2;
      ns = ns_St_Junction2;
      nr = nr_St_Junction2;
      break;
    case Line_follower__St_Normal3:
      v_109 = (self->v_108-1);
      if (self->v_106) {
        v_107 = true;
      } else {
        v_107 = r;
      };
      if (v_107) {
        time_St_Normal3 = 100;
      } else {
        time_St_Normal3 = v_109;
      };
      stateno_St_Normal3 = 5;
      v_103 = (2*_out->correction);
      v_104 = (base_speed+v_103);
      Line_follower__abs_step(v_104, &Line_follower__abs_out_st);
      v_105 = Line_follower__abs_out_st.b;
      v_102 = (base_speed+_out->correction);
      v_101 = (_out->correction>0);
      if (v_101) {
        v_l_St_Normal3 = v_102;
      } else {
        v_l_St_Normal3 = v_105;
      };
      v_100 = (base_speed-_out->correction);
      v_97 = (2*_out->correction);
      v_98 = (base_speed-v_97);
      Line_follower__abs_step(v_98, &Line_follower__abs_out_st);
      v_99 = Line_follower__abs_out_st.b;
      v_96 = (_out->correction>0);
      if (v_96) {
        v_r_St_Normal3 = v_99;
      } else {
        v_r_St_Normal3 = v_100;
      };
      v_92 = (2*_out->correction);
      v_93 = (base_speed+v_92);
      v_94 = (v_93<0);
      if (v_94) {
        v_95 = 2;
      } else {
        v_95 = 1;
      };
      v_89 = (2*_out->correction);
      v_90 = (base_speed-v_89);
      v_91 = (v_90<0);
      if (v_91) {
        dir_St_Normal3 = 3;
      } else {
        dir_St_Normal3 = v_95;
      };
      if (ir1) {
        v_88 = true;
        v_87 = Line_follower__St_Obstacle1;
      } else {
        v_88 = false;
        v_87 = Line_follower__St_Normal3;
      };
      v_84 = sen[3];
      v_85 = (v_84>500);
      v_81 = sen[2];
      v_82 = (v_81>400);
      v_78 = sen[1];
      v_79 = (v_78>500);
      _out->v_l = v_l_St_Normal3;
      _out->v_r = v_r_St_Normal3;
      _out->dir = dir_St_Normal3;
      _out->stateno = stateno_St_Normal3;
      time = time_St_Normal3;
      v_77 = (time<0);
      v_80 = (v_77&&v_79);
      v_83 = (v_80&&v_82);
      v_86 = (v_83&&v_85);
      if (v_86) {
        nr_St_Normal3 = true;
        ns_St_Normal3 = Line_follower__St_Junction3;
      } else {
        nr_St_Normal3 = v_88;
        ns_St_Normal3 = v_87;
      };
      ns = ns_St_Normal3;
      nr = nr_St_Normal3;
      self->v_108 = time;
      self->v_106 = false;
      break;
    case Line_follower__St_Obstacle6:
      v_71 = sen[2];
      time_St_Obstacle6 = 0;
      stateno_St_Obstacle6 = 13;
      dir_St_Obstacle6 = 1;
      v_l_St_Obstacle6 = 50;
      v_r_St_Obstacle6 = 50;
      v_72 = (v_71>600);
      if (v_72) {
        nr_St_Obstacle6 = true;
        ns_St_Obstacle6 = Line_follower__St_Normal3;
      } else {
        nr_St_Obstacle6 = false;
        ns_St_Obstacle6 = Line_follower__St_Obstacle6;
      };
      _out->v_l = v_l_St_Obstacle6;
      _out->v_r = v_r_St_Obstacle6;
      _out->dir = dir_St_Obstacle6;
      _out->stateno = stateno_St_Obstacle6;
      time = time_St_Obstacle6;
      ns = ns_St_Obstacle6;
      nr = nr_St_Obstacle6;
      break;
    case Line_follower__St_Obstacle1:
      time_St_Obstacle1 = 0;
      stateno_St_Obstacle1 = 7;
      dir_St_Obstacle1 = 3;
      v_l_St_Obstacle1 = 50;
      v_r_St_Obstacle1 = 25;
      v_75 = !(ir3);
      v_76 = (ir2&&v_75);
      if (v_76) {
        nr_St_Obstacle1 = true;
        ns_St_Obstacle1 = Line_follower__St_Obstacle2;
      } else {
        nr_St_Obstacle1 = false;
        ns_St_Obstacle1 = Line_follower__St_Obstacle1;
      };
      _out->v_l = v_l_St_Obstacle1;
      _out->v_r = v_r_St_Obstacle1;
      _out->dir = dir_St_Obstacle1;
      _out->stateno = stateno_St_Obstacle1;
      time = time_St_Obstacle1;
      ns = ns_St_Obstacle1;
      nr = nr_St_Obstacle1;
      break;
    case Line_follower__St_Obstacle2:
      stateno_St_Obstacle2 = 8;
      time_St_Obstacle2 = 0;
      dir_St_Obstacle2 = 1;
      v_l_St_Obstacle2 = 50;
      v_r_St_Obstacle2 = 50;
      v_74 = !(ir2);
      if (v_74) {
        nr_St_Obstacle2 = true;
        ns_St_Obstacle2 = Line_follower__St_Obstacle3;
      } else {
        nr_St_Obstacle2 = false;
        ns_St_Obstacle2 = Line_follower__St_Obstacle2;
      };
      _out->v_l = v_l_St_Obstacle2;
      _out->v_r = v_r_St_Obstacle2;
      _out->dir = dir_St_Obstacle2;
      _out->stateno = stateno_St_Obstacle2;
      time = time_St_Obstacle2;
      ns = ns_St_Obstacle2;
      nr = nr_St_Obstacle2;
      break;
    case Line_follower__St_Obstacle3:
      stateno_St_Obstacle3 = 9;
      time_St_Obstacle3 = 0;
      dir_St_Obstacle3 = 1;
      v_l_St_Obstacle3 = 20;
      v_r_St_Obstacle3 = 50;
      if (ir3) {
        nr_St_Obstacle3 = true;
        ns_St_Obstacle3 = Line_follower__St_Right;
      } else {
        nr_St_Obstacle3 = false;
        ns_St_Obstacle3 = Line_follower__St_Obstacle3;
      };
      _out->v_l = v_l_St_Obstacle3;
      _out->v_r = v_r_St_Obstacle3;
      _out->dir = dir_St_Obstacle3;
      _out->stateno = stateno_St_Obstacle3;
      time = time_St_Obstacle3;
      ns = ns_St_Obstacle3;
      nr = nr_St_Obstacle3;
      break;
    case Line_follower__St_Right:
      stateno_St_Right = 10;
      time_St_Right = 0;
      dir_St_Right = 3;
      v_r_St_Right = 50;
      v_l_St_Right = 50;
      if (ir2) {
        nr_St_Right = true;
        ns_St_Right = Line_follower__St_Obstacle4;
      } else {
        nr_St_Right = false;
        ns_St_Right = Line_follower__St_Right;
      };
      _out->v_l = v_l_St_Right;
      _out->v_r = v_r_St_Right;
      _out->dir = dir_St_Right;
      _out->stateno = stateno_St_Right;
      time = time_St_Right;
      ns = ns_St_Right;
      nr = nr_St_Right;
      break;
    case Line_follower__St_Obstacle4:
      time_St_Obstacle4 = 0;
      stateno_St_Obstacle4 = 11;
      dir_St_Obstacle4 = 1;
      v_l_St_Obstacle4 = 50;
      v_r_St_Obstacle4 = 50;
      v_73 = !(ir2);
      if (v_73) {
        nr_St_Obstacle4 = true;
        ns_St_Obstacle4 = Line_follower__St_Obstacle5;
      } else {
        nr_St_Obstacle4 = false;
        ns_St_Obstacle4 = Line_follower__St_Obstacle4;
      };
      _out->v_l = v_l_St_Obstacle4;
      _out->v_r = v_r_St_Obstacle4;
      _out->dir = dir_St_Obstacle4;
      _out->stateno = stateno_St_Obstacle4;
      time = time_St_Obstacle4;
      ns = ns_St_Obstacle4;
      nr = nr_St_Obstacle4;
      break;
    case Line_follower__St_Obstacle5:
      time_St_Obstacle5 = 0;
      stateno_St_Obstacle5 = 12;
      dir_St_Obstacle5 = 1;
      v_l_St_Obstacle5 = 20;
      v_r_St_Obstacle5 = 50;
      if (ir2) {
        nr_St_Obstacle5 = true;
        ns_St_Obstacle5 = Line_follower__St_Obstacle6;
      } else {
        nr_St_Obstacle5 = false;
        ns_St_Obstacle5 = Line_follower__St_Obstacle5;
      };
      _out->v_l = v_l_St_Obstacle5;
      _out->v_r = v_r_St_Obstacle5;
      _out->dir = dir_St_Obstacle5;
      _out->stateno = stateno_St_Obstacle5;
      time = time_St_Obstacle5;
      ns = ns_St_Obstacle5;
      nr = nr_St_Obstacle5;
      break;
    case Line_follower__St_Junction3:
      time_St_Junction3 = 0;
      stateno_St_Junction3 = 6;
      dir_St_Junction3 = 2;
      v_r_St_Junction3 = 40;
      v_l_St_Junction3 = 60;
      nr_St_Junction3 = false;
      ns_St_Junction3 = Line_follower__St_Junction3;
      _out->v_l = v_l_St_Junction3;
      _out->v_r = v_r_St_Junction3;
      _out->dir = dir_St_Junction3;
      _out->stateno = stateno_St_Junction3;
      time = time_St_Junction3;
      ns = ns_St_Junction3;
      nr = nr_St_Junction3;
      break;
    default:
      break;
  };
  self->error_1 = error;
  self->pnr = nr;
  self->ck = ns;
  self->v_38 = integral;
  self->v_37 = false;;
}

void Line_follower__less_step(int a, int out, Line_follower__less_out* _out) {
  
  int v;
  v = (a<out);
  if (v) {
    _out->b = a;
  } else {
    _out->b = out;
  };;
}

void Line_follower__more_step(int a, int out, Line_follower__more_out* _out) {
  
  int v;
  v = (a>out);
  if (v) {
    _out->b = a;
  } else {
    _out->b = out;
  };;
}

void Line_follower__caliberate_step(int v, int min, int max,
                                    Line_follower__caliberate_out* _out) {
  
  int v_169;
  int v_168;
  int v_167;
  v_169 = (max-min);
  v_167 = (v-min);
  v_168 = (1000*v_167);
  _out->cal_val = (v_168/v_169);;
}

void Line_follower__main_reset(Line_follower__main_mem* self) {
  Line_follower__line_follower_reset(&self->line_follower);
  self->v_176 = true;
}

void Line_follower__main_step(int sen0, int sen1, int sen2, int sen3,
                              int sen4, int ir0, int ir1, int ir2, int ir3,
                              Line_follower__main_out* _out,
                              Line_follower__main_mem* self) {
  Line_follower__line_follower_out Line_follower__line_follower_out_st;
  
  int v_186[5];
  int v_185[5];
  int v_184;
  int v_183;
  int v_182;
  int v_181;
  int v_180;
  int v_179;
  int v_177;
  int v_175;
  int v_174;
  int v_173;
  int v_172;
  int v_171;
  int v_170;
  int v;
  int out[5];
  int line_switch;
  _out->s4 = sen4;
  _out->s3 = sen3;
  _out->s2 = sen2;
  _out->s1 = sen1;
  _out->s0 = sen0;
  v_184 = (1023-sen4);
  v_183 = (1023-sen3);
  v_182 = (1023-sen2);
  v_181 = (1023-sen1);
  v_180 = (1023-sen0);
  v_175 = (2*sen2);
  v_173 = (sen4*1);
  v_170 = (sen1*1);
  v = (sen0*1);
  v_171 = (v+v_170);
  v_172 = (v_171+sen3);
  v_174 = (v_172+v_173);
  _out->err = (v_174-v_175);
  v_177 = (_out->err>1000);
  v_179 = (v_177||self->v_178);
  if (self->v_176) {
    line_switch = false;
  } else {
    line_switch = v_179;
  };
  _out->ls = line_switch;
  v_186[0] = sen0;
  v_186[1] = sen1;
  v_186[2] = sen2;
  v_186[3] = sen3;
  v_186[4] = sen4;
  v_185[0] = v_180;
  v_185[1] = v_181;
  v_185[2] = v_182;
  v_185[3] = v_183;
  v_185[4] = v_184;
  if (line_switch) {
    {
      int _1;
      for (_1 = 0; _1 < 5; ++_1) {
        out[_1] = v_185[_1];
      }
    };
  } else {
    {
      int _2;
      for (_2 = 0; _2 < 5; ++_2) {
        out[_2] = v_186[_2];
      }
    };
  };
  Line_follower__line_follower_step(out, line_switch, ir0, ir1, ir2, ir3,
                                    &Line_follower__line_follower_out_st,
                                    &self->line_follower);
  _out->v_l = Line_follower__line_follower_out_st.v_l;
  _out->v_r = Line_follower__line_follower_out_st.v_r;
  _out->dir = Line_follower__line_follower_out_st.dir;
  _out->correction = Line_follower__line_follower_out_st.correction;
  _out->stateno = Line_follower__line_follower_out_st.stateno;
  self->v_178 = line_switch;
  self->v_176 = false;;
}

