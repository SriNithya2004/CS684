/* --- Generated the 31/3/2025 at 5:9 --- */
/* --- heptagon compiler, version 1.05.00 (compiled wed. mar. 19 17:12:18 CET 2025) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts line_follower.ept --- */

#ifndef LINE_FOLLOWER_TYPES_H
#define LINE_FOLLOWER_TYPES_H

#include "stdbool.h"
#include "assert.h"
#include "pervasives.h"
typedef enum {
  Line_follower__St_ZNormal,
  Line_follower__St_Right,
  Line_follower__St_Obstacle6,
  Line_follower__St_Obstacle5,
  Line_follower__St_Obstacle4,
  Line_follower__St_Obstacle3,
  Line_follower__St_Obstacle2,
  Line_follower__St_Obstacle1,
  Line_follower__St_Normal3,
  Line_follower__St_Normal2,
  Line_follower__St_Junction3,
  Line_follower__St_Junction2,
  Line_follower__St_Junction1
} Line_follower__st;

Line_follower__st Line_follower__st_of_string(char* s);

char* string_of_Line_follower__st(Line_follower__st x, char* buf);

#endif // LINE_FOLLOWER_TYPES_H
