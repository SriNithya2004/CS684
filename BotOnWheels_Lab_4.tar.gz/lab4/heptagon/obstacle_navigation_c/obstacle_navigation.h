/* --- Generated the 28/3/2025 at 6:36 --- */
/* --- heptagon compiler, version 1.05.00 (compiled thu. mar. 20 22:35:38 CET 2025) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts obstacle_navigation.ept --- */

#ifndef OBSTACLE_NAVIGATION_H
#define OBSTACLE_NAVIGATION_H

#include "obstacle_navigation_types.h"
typedef struct Obstacle_navigation__black_check_out {
  int out;
} Obstacle_navigation__black_check_out;

void Obstacle_navigation__black_check_step(int sen0, int sen1, int sen2,
                                           int sen3, int sen4,
                                           Obstacle_navigation__black_check_out* _out);

typedef struct Obstacle_navigation__main_mem {
  int v_32;
  int v_28;
  int v_24;
  int v;
} Obstacle_navigation__main_mem;

typedef struct Obstacle_navigation__main_out {
  int mode;
  int v_l;
  int v_r;
} Obstacle_navigation__main_out;

void Obstacle_navigation__main_reset(Obstacle_navigation__main_mem* self);

void Obstacle_navigation__main_step(int sen0, int sen1, int sen2, int sen3,
                                    int sen4, int ir0, int ir1, int ir2,
                                    Obstacle_navigation__main_out* _out,
                                    Obstacle_navigation__main_mem* self);

#endif // OBSTACLE_NAVIGATION_H
