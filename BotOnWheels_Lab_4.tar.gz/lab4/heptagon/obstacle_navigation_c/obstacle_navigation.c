/* --- Generated the 28/3/2025 at 6:36 --- */
/* --- heptagon compiler, version 1.05.00 (compiled thu. mar. 20 22:35:38 CET 2025) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts obstacle_navigation.ept --- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "obstacle_navigation.h"

void Obstacle_navigation__black_check_step(int sen0, int sen1, int sen2,
                                           int sen3, int sen4,
                                           Obstacle_navigation__black_check_out* _out) {
  
  int v_23;
  int v_22;
  int v_21;
  int v_20;
  int v_19;
  int v_18;
  int v_17;
  int v_16;
  int v_15;
  int v_14;
  int v_13;
  int v_12;
  int v_11;
  int v_10;
  int v_9;
  int v_8;
  int v_7;
  int v_6;
  int v_5;
  int v_4;
  int v_3;
  int v_2;
  int v_1;
  int v;
  int avg;
  int param;
  param = 100;
  v = (sen0+sen1);
  v_1 = (v+sen2);
  v_2 = (v_1+sen3);
  v_3 = (v_2+sen4);
  avg = (v_3/5);
  v_20 = (sen4-avg);
  v_19 = (sen4-avg);
  v_21 = (v_19*v_20);
  v_16 = (sen3-avg);
  v_15 = (sen3-avg);
  v_17 = (v_15*v_16);
  v_12 = (sen2-avg);
  v_11 = (sen2-avg);
  v_13 = (v_11*v_12);
  v_8 = (sen1-avg);
  v_7 = (sen1-avg);
  v_9 = (v_7*v_8);
  v_5 = (sen0-avg);
  v_4 = (sen0-avg);
  v_6 = (v_4*v_5);
  v_10 = (v_6+v_9);
  v_14 = (v_10+v_13);
  v_18 = (v_14+v_17);
  v_22 = (v_18+v_21);
  v_23 = (v_22<100);
  if (v_23) {
    _out->out = true;
  } else {
    _out->out = false;
  };;
}

void Obstacle_navigation__main_reset(Obstacle_navigation__main_mem* self) {
  self->v = true;
}

void Obstacle_navigation__main_step(int sen0, int sen1, int sen2, int sen3,
                                    int sen4, int ir0, int ir1, int ir2,
                                    Obstacle_navigation__main_out* _out,
                                    Obstacle_navigation__main_mem* self) {
  Obstacle_navigation__black_check_out Obstacle_navigation__black_check_out_st;
  
  int v_38;
  int v_37;
  int v_36;
  int v_35;
  int v_34;
  int v_33;
  int v_31;
  int v_30;
  int v_29;
  int v_27;
  int v_26;
  int v_25;
  if (ir2) {
    v_38 = 50;
  } else {
    v_38 = 25;
  };
  v_37 = (ir0||ir1);
  if (v_37) {
    _out->v_r = 50;
  } else {
    _out->v_r = v_38;
  };
  if (ir2) {
    v_36 = 50;
  } else {
    v_36 = 50;
  };
  v_35 = (ir0||ir1);
  if (v_35) {
    _out->v_l = 10;
  } else {
    _out->v_l = v_36;
  };
  Obstacle_navigation__black_check_step(sen0, sen1, sen2, sen3, sen4,
                                        &Obstacle_navigation__black_check_out_st);
  v_29 = Obstacle_navigation__black_check_out_st.out;
  v_30 = !(v_29);
  v_31 = (self->v_28&&v_30);
  if (v_31) {
    v_33 = false;
  } else {
    v_33 = self->v_32;
  };
  v_26 = (ir0||ir1);
  v_25 = !(self->v_24);
  v_27 = (v_25&&v_26);
  if (v_27) {
    v_34 = true;
  } else {
    v_34 = v_33;
  };
  if (self->v) {
    _out->mode = false;
  } else {
    _out->mode = v_34;
  };
  self->v_32 = _out->mode;
  self->v_28 = _out->mode;
  self->v_24 = _out->mode;
  self->v = false;;
}

