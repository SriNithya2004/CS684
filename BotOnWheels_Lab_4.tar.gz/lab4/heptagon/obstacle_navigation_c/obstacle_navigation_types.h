/* --- Generated the 28/3/2025 at 6:36 --- */
/* --- heptagon compiler, version 1.05.00 (compiled thu. mar. 20 22:35:38 CET 2025) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts obstacle_navigation.ept --- */

#ifndef OBSTACLE_NAVIGATION_TYPES_H
#define OBSTACLE_NAVIGATION_TYPES_H

#include "stdbool.h"
#include "assert.h"
#include "pervasives.h"
#endif // OBSTACLE_NAVIGATION_TYPES_H
