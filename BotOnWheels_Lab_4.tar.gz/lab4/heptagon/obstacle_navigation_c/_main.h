/* --- Generated the 28/3/2025 at 6:36 --- */
/* --- heptagon compiler, version 1.05.00 (compiled thu. mar. 20 22:35:38 CET 2025) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts obstacle_navigation.ept --- */

#ifndef _MAIN_H
#define _MAIN_H

#include "obstacle_navigation.h"
#endif // _MAIN_H
