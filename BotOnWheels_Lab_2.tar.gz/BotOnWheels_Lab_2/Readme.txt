assumptions :

1. assuming there are no 3 (or) more way intersections or loops as in no( Ts or +)
2. left motor causes the bot to turn left and right motor makes it turn left
    high right velocity, low left velocity makes the bot turn LEFT
    high left velocity, low right velocity makes the bot turn RIGHT

3. We assume that the values of Ki, Kd, Kp, base_speed are tuned for various parameters during the physical implementation
    and for now we are assuming some dummy values 
    (and showcasing the working PID implementation with these dummy values)

conditions :
1. defined correction constants as integers and made error term smaller
    by dividing it by "den" (i.e 100) so that the correction constants PID would be in the order of 10^0 i.e integers

2. multiplied the error with vector (-2, -1, 0, 1, 2) so that the correction parameters would be more accurate
    i.e differentiating between the drift towards left and right.

3. stopping the bot in case of all sensors giving high values assuming to be end state
   considering above "high_val" (i.e800) as high values

4. traversing backward if all sensors show low values, i.e detecting drift from path
   considering below "low_val" (i.e200) as low values

5. if error is 0 proceeds forward, else if negative then left else if positive then right

S.no    input                       output
1       0,0,1023,0,0                1, 50, 50  
2       0,0,1023,1023,800           3, 30, 70       
3       0,0,800,200,0               3, 45, 55
4       0,100,900,0,0               2, 53, 47
5       1023,1023,1023,0,0          2, 75, 25      
6       0,0,1023,0,0                1, 50, 50
7       1023,1023,1023,0,0          2, 75, 25
8       0,200,800,0,0               2, 55, 45
9       0,0,1023,1023,1023          3, 25,75
10      0,0,823,200,0               3, 45, 55
11      0,0,1023,1023,1023          3, 25,75
12      0,0,1023,0,0                1, 50, 50
13      0,0,1023,0,0                1, 50, 50
14      0,0,1023,600,400            3, 40, 60
15      0,0,800,100,100             3, 48, 52
16      0,400,600,0,0               2, 65, 35
17      0,0,1023,1023,1023          3, 25,75
18      0,200,1023,0,0              2, 70, 30
19      0,0,1023,0,0                1, 50, 50
20      1023,1023,1023,0,0          2, 75, 25
21      1023,1023,1023,1023,1023    0, 0, 0



link of simulation :
https://youtu.be/QHGz8IuwQjo

NOTE:
(while simulating we are interpreting  (0 to 1023) as -> (0 to 50)
and used low_val 10, high_val 40, den 5 while simulating
so in the outputs direction is correct but the velocities values vary wrt those reported above)