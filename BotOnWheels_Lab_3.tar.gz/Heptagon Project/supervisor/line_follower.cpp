/* --- Generated the 21/3/2025 at 3:35 --- */
/* --- heptagon compiler, version 1.05.00 (compiled thu. mar. 20 22:35:38 CET 2025) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts line_follower.ept --- */

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "line_follower.h"

void Line_follower__line_follower_reset(Line_follower__line_follower_mem* self) {
  self->error_1 = 0;
  self->v_13 = true;
}

void Line_follower__line_follower_step(long sen[5],
                                       Line_follower__line_follower_out* _out,
                                       Line_follower__line_follower_mem* self) {
  
  long v_34;
  long v_33;
  long v_32;
  long v_31;
  long v_30;
  long v_29;
  long v_28;
  long v_27;
  long v_26;
  long v_25;
  long v_24;
  long v_23;
  long v_22;
  long v_21;
  long v_20;
  long v_19;
  long v_18;
  long v_17;
  long v_16;
  long v_15;
  long v_12;
  long v_11;
  long v_10;
  long v_9;
  long v_8;
  long v_7;
  long v_6;
  long v_5;
  long v_4;
  long v_3;
  long v_2;
  long v_1;
  long v;
  long error;
  long longegral;
  long derivative;
  long kp;
  long ki;
  long kd;
  long base_speed;
  long correction;
  v_11 = sen[4];
  v_12 = (v_11*2);
  v_8 = sen[3];
  v_9 = (v_8*1);
  v_5 = sen[2];
  v_6 = (v_5*0);
  v_2 = sen[1];
  v = sen[0];
  v_3 = (v_2*-1);
  v_1 = (v*-2);
  v_4 = (v_1+v_3);
  v_7 = (v_4+v_6);
  v_10 = (v_7+v_9);
  error = (v_10+v_12);
  derivative = (error-self->error_1);
  v_15 = (self->v_14+error);
  if (self->v_13) {
    longegral = 0;
  } else {
    longegral = v_15;
  };
  base_speed = 50;
  kd = 0;
  v_19 = (kd*derivative);
  ki = 0;
  v_17 = (ki*longegral);
  kp = 50;
  v_16 = (kp*error);
  v_18 = (v_16+v_17);
  v_20 = (v_18+v_19);
  correction = (v_20/1000);
  v_32 = (base_speed+correction);
  v_33 = (v_32/2);
  v_30 = (base_speed+correction);
  v_31 = (v_30>100);
  if (v_31) {
    v_34 = 50;
  } else {
    v_34 = v_33;
  };
  v_28 = (base_speed+correction);
  v_29 = (v_28<0);
  if (v_29) {
    _out->v_r = 0;
  } else {
    _out->v_r = v_34;
  };
  v_25 = (base_speed-correction);
  v_26 = (v_25/2);
  v_23 = (base_speed-correction);
  v_24 = (v_23>100);
  if (v_24) {
    v_27 = 50;
  } else {
    v_27 = v_26;
  };
  v_21 = (base_speed-correction);
  v_22 = (v_21<0);
  if (v_22) {
    _out->v_l = 0;
  } else {
    _out->v_l = v_27;
  };
  self->error_1 = error;
  self->v_14 = longegral;
  self->v_13 = false;;
}

void Line_follower__less_step(long a, long out, Line_follower__less_out* _out) {
  
  long v;
  v = (a<out);
  if (v) {
    _out->b = a;
  } else {
    _out->b = out;
  };;
}

void Line_follower__more_step(long a, long out, Line_follower__more_out* _out) {
  
  long v;
  v = (a>out);
  if (v) {
    _out->b = a;
  } else {
    _out->b = out;
  };;
}

void Line_follower__caliberate_step(long v, long min, long max,
                                    Line_follower__caliberate_out* _out) {
  
  long v_37;
  long v_36;
  long v_35;
  v_37 = (max-min);
  v_35 = (v-min);
  v_36 = (1000*v_35);
  _out->cal_val = (v_36/v_37);;
}

void Line_follower__main_reset(Line_follower__main_mem* self) {
  Line_follower__line_follower_reset(&self->line_follower);
}

void Line_follower__main_step(long sen0, long sen1, long sen2, long sen3,
                              long sen4, Line_follower__main_out* _out,
                              Line_follower__main_mem* self) {
  Line_follower__line_follower_out Line_follower__line_follower_out_st;
  
  long sen[5];
  long out[5];
  sen[0] = sen0;
  sen[1] = sen1;
  sen[2] = sen2;
  sen[3] = sen3;
  sen[4] = sen4;
  {
    long _1;
    for (_1 = 0; _1 < 5; ++_1) {
      out[_1] = sen[_1];
    }
  };
  Line_follower__line_follower_step(out,
                                    &Line_follower__line_follower_out_st,
                                    &self->line_follower);
  _out->v_l = Line_follower__line_follower_out_st.v_l;
  _out->v_r = Line_follower__line_follower_out_st.v_r;;
}

