/* --- Generated the 21/3/2025 at 3:35 --- */
/* --- heptagon compiler, version 1.05.00 (compiled thu. mar. 20 22:35:38 CET 2025) --- */
/* --- Command line: /usr/local/bin/heptc -target c -s main -hepts line_follower.ept --- */

#ifndef LINE_FOLLOWER_H
#define LINE_FOLLOWER_H

#include "line_follower_types.h"
typedef struct Line_follower__line_follower_mem {
  long v_14;
  long v_13;
  long error_1;
} Line_follower__line_follower_mem;

typedef struct Line_follower__line_follower_out {
  long v_l;
  long v_r;
} Line_follower__line_follower_out;

void Line_follower__line_follower_reset(Line_follower__line_follower_mem* self);

void Line_follower__line_follower_step(long sen[5],
                                       Line_follower__line_follower_out* _out,
                                       Line_follower__line_follower_mem* self);

typedef struct Line_follower__less_out {
  long b;
} Line_follower__less_out;

void Line_follower__less_step(long a, long out, Line_follower__less_out* _out);

typedef struct Line_follower__more_out {
  long b;
} Line_follower__more_out;

void Line_follower__more_step(long a, long out, Line_follower__more_out* _out);

typedef struct Line_follower__caliberate_out {
  long cal_val;
} Line_follower__caliberate_out;

void Line_follower__caliberate_step(long v, long min, long max,
                                    Line_follower__caliberate_out* _out);

typedef struct Line_follower__main_mem {
  Line_follower__line_follower_mem line_follower;
} Line_follower__main_mem;

typedef struct Line_follower__main_out {
  long v_l;
  long v_r;
} Line_follower__main_out;

void Line_follower__main_reset(Line_follower__main_mem* self);

void Line_follower__main_step(long sen0, long sen1, long sen2, long sen3,
                              long sen4, Line_follower__main_out* _out,
                              Line_follower__main_mem* self);

#endif // LINE_FOLLOWER_H
